library(lubridate)
library(dplyr)
library(tidyr)
library(ggplot2)
library(scales)
library(patchwork)

# Set working directory
setwd("C:/Users/lpakkila/OneDrive - Oulun yliopisto/Lassin väitöskirjatyö/Peatland water table and quality/Runoff_and_load/Daily_data/CSV_Daily_runoff_and_load_main_with_estimates/")

# List all CSV files in the directory
csv_files <- list.files(pattern = "\\.csv$")
# List of WQ parameters
parameters <- c("Ptot", "e_Ptot", "Ntot", "e_Ntot", "DOC", "e_DOC")
# Create an empty list to store output dataframes
output_list <- list()

# Loop through csv_files and import CSV files into individual dataframes
for (file in csv_files) {
  # Extract filename without extension
  obs_point <- sub("\\.csv$", "", file)
  
  # Read CSV file with specific parameters and assign directly to a dataframe with filename
  assign(obs_point, read.csv(file, sep = ";", header = TRUE, dec = "."))
  
  # Edit the date and time column using lubridate
  if ("Date" %in% colnames(get(obs_point))) {
    assign(obs_point, transform(get(obs_point), Date = dmy(Date, tz = NULL)))
  }
  
  # Add a calendar year column
  if ("Date" %in% colnames(get(obs_point))) {
    assign(obs_point, transform(get(obs_point), Cal_year = format(Date, '%Y')))
  }
  
  # Loop through each parameter
  for (param in parameters) {
    # Calculate seasonal load for each years each season
    for (season in c(1, 2)) {
      seasonal_load <- aggregate(get(obs_point)[[paste0(param, "_kg_ha")]], by = list(Cal_year = get(obs_point)$Cal_year, Season = get(obs_point)$Season), FUN = sum)
      seasonal_load <- seasonal_load[seasonal_load$Season == season, ]
      colnames(seasonal_load) <- c("Cal_year", "Season", paste0(param, "_load"))
      seasonal_load$Site <- get(obs_point)$Site[1]
      
      # Keep "Res_pris" column
      seasonal_load$Res_pris <- get(obs_point)$Res_pris[1]
      
      # Append the seasonal_load dataframe to the output list
      output_list[[length(output_list) + 1]] <- seasonal_load
    }
  }
}

# Aggregate the load data separately for each parameter into a dataframe "yearly_load"
yearly_load <- bind_rows(output_list) %>%
  group_by(Site, Cal_year, Season) %>%
  summarise(
    across(matches("_load$"), \(x) sum(x, na.rm = TRUE)), # Sum load columns
    Res_pris = first(Res_pris) # Keep Res_pris column
  ) %>%
  select(Site, Res_pris, everything()) # Reorder columns
# Reorder levels of the Season variable so that Season 1 appears first
yearly_load$Season <- factor(yearly_load$Season, levels = c(2, 1))

# Modify the yearly_load dataframe for plotting
yearly_load$e_Ptot_load[yearly_load$e_Ptot_load == 0] <- NA
yearly_load$e_Ntot_load[yearly_load$e_Ntot_load == 0] <- NA
yearly_load$e_DOC_load[yearly_load$e_DOC_load == 0] <- NA

# Save yearly_load as a CSV file in the working directory
write.table(yearly_load, sep = ";", row.names = FALSE, col.names = TRUE, 
            file = "C:/Users/lpakkila/OneDrive - Oulun yliopisto/Lassin väitöskirjatyö/Peatland water table and quality/Runoff_and_load/yearly_load.csv")

# Create an empty list to store monthly Q_l_s dataframes
monthly_Q_l_s_list <- list()

# Loop through csv_files and calculate the monthly mean of Q_l_s for each site across all years
for (file in csv_files) {
  # Extract filename without extension
  obs_point <- sub("\\.csv$", "", file)
  
  # Get the dataframe for the site
  site_data <- get(obs_point)
  
  # Check if the Q_l_s column exists in the dataframe
  if ("Q_l_s" %in% colnames(site_data)) {
    # Calculate the monthly mean Q_l_s for the site across all years
    monthly_Q_l_s <- site_data %>%
      mutate(Month = month(Date, label = TRUE)) %>%
      group_by(Site, Month) %>%
      summarize(mean_Q_l_s = mean(Q_l_s, na.rm = TRUE)) %>%
      ungroup()
    
    # Store the result in the list
    monthly_Q_l_s_list[[obs_point]] <- monthly_Q_l_s
  }
}

# Combine all site results into a single dataframe
monthly_Q_l_s_combined <- bind_rows(monthly_Q_l_s_list)

# Print the result
print(monthly_Q_l_s_combined)


# Custom theme for the plots
custom_theme <- theme_bw(base_size = 10) +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5),
    axis.title = element_text(size = 10),#, face = "bold"), # Adjust size and font properties for axis titles
    axis.text = element_text(size = 10),               # Adjust size and font properties for axis labels
    legend.position = "bottom",
    legend.title = element_blank(),
    legend.text = element_text(size = 10),              # Adjust size and font properties for legend text
    panel.grid.major.x = element_blank(), 
    panel.grid.minor.x = element_line(linewidth = 0.5, linetype = 'solid',
                                    colour = "grey")
  ) 

#Colors <- ("#E69F00", "#0072B2", "#F0E442", "#009E73")

########################################
# Ptot yearly load Site S3
# Define custom colors and labels for the fill scale
custom_colors <- c("Ptot_load.2"="#E69F00", 
                   "Ptot_load.1"="#0072B2",
                   "e_Ptot_load.2"="#F0E442", 
                   "e_Ptot_load.1"="#009E73") # Customize colors
custom_labels <- c("Ptot_load.2" = "Observed Q and/or runoff concentration", 
                   "Ptot_load.1" = "Estimated frost season Q and runoff concentration", 
                   "e_Ptot_load.2" = "Observed Q and/or regression modeled runoff concentration", 
                   "e_Ptot_load.1" = "Estimated frost season Q and regression modeled runoff concentration")
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "S3",] %>%
  pivot_longer(cols = c(Ptot_load, e_Ptot_load), names_to = "Ptot_type", values_to = "Ptot_value")
plot_data$Ptot_type <- factor(plot_data$Ptot_type, levels = c("Ptot_load", "e_Ptot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ptot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))

# Plot with reordered legend
PS3 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ptot_value, x = as.numeric(interaction(Ptot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("P"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 19), xlim = c(1.2, 19.8)) +
  scale_y_continuous(breaks = seq(0, 20, 5), labels = scales::number_format(accuracy = 0.1)) +
  scale_x_continuous(breaks = x_breaks, labels = x_labels) +
  guides(fill = guide_legend(title="Runoff load from:", nrow = 4, byrow = TRUE)) +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
PS3

# Ntot yearly load Site S3
# Define custom colors and labels for the fill scale
custom_colors <- c("Ntot_load.2"="#E69F00", 
                   "Ntot_load.1"="#0072B2", 
                   "e_Ntot_load.2"="#F0E442", 
                   "e_Ntot_load.1"="#009E73")  # Customize colors
custom_labels <- c("Ntot_load.2" = expression(Q[O]*" and N"[tot~","~O]), 
                   "Ntot_load.1" = expression(Q[E]*" and N"[tot~","~O]), 
                   "e_Ntot_load.2" = expression(Q[O]*" and N"[tot~","~E]), 
                   "e_Ntot_load.1" = expression(Q[E]*" and N"[tot~","~E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "S3",] %>%
  pivot_longer(cols = c(Ntot_load, e_Ntot_load), names_to = "Ntot_type", values_to = "Ntot_value")
plot_data$Ntot_type <- factor(plot_data$Ntot_type, levels = c("Ntot_load", "e_Ntot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ntot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
NS3 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ntot_value, x = as.numeric(interaction(Ntot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("N"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 9), xlim = c(1.2, 19.8)) +
  scale_y_continuous(breaks = seq(0, 10, 2), labels = scales::number_format(accuracy = 0.1)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  theme(legend.position = "none") +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
NS3

# DOC yearly load Site S3
# Define custom colors and labels for the fill scale
custom_colors <- c("DOC_load.2"="#E69F00", 
                   "DOC_load.1"="#0072B2", 
                   "e_DOC_load.2"="#F0E442", 
                   "e_DOC_load.1"="#009E73")  # Customize colors
custom_labels <- c("DOC_load.2" = expression(Q[O]*" and DOC"[M]), 
                   "DOC_load.1" = expression(Q[E]*" and DOC"[M]), 
                   "e_DOC_load.2" = expression(Q[O]*" and DOC"[E]), 
                   "e_DOC_load.1" = expression(Q[E]*" and DOC"[E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "S3",] %>%
  pivot_longer(cols = c(DOC_load, e_DOC_load), names_to = "DOC_type", values_to = "DOC_value")
plot_data$DOC_type <- factor(plot_data$DOC_type, levels = c("DOC_load", "e_DOC_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$DOC_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
DOCS3 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = DOC_value, x = as.numeric(interaction(DOC_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = "S3",
       x = NULL,
       y = expression("DOC load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 600), xlim = c(1.2, 19.8)) +
  scale_y_continuous(breaks = seq(0, 600, 100)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  theme(legend.position = "none") +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
DOCS3

S3 <- (DOCS3/NS3/PS3)
S3

# Save the plot using ggsave
ggsave("S3_yearly_load.tiff", 
       plot = S3, 
       device = "tiff", 
       width = 3740, height = 4624, dpi = 500, units = "px", bg = "white")


##########################################
# Ptot yearly load Site SC3
# Define custom colors and labels for the fill scale
custom_colors <- c("Ptot_load.2"="#E69F00", 
                   "Ptot_load.1"="#0072B2", 
                   "e_Ptot_load.2"="#F0E442", 
                   "e_Ptot_load.1"="#009E73") # Customize colors
custom_labels <- c("Ptot_load.2" = "Observed Q and/or runoff concentration", 
                   "Ptot_load.1" = "Estimated frost season Q and runoff concentration", 
                   "e_Ptot_load.2" = "Observed Q and/or regression modeled runoff concentration", 
                   "e_Ptot_load.1" = "Estimated frost season Q and regression modeled runoff concentration")
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "SC3",] %>%
  pivot_longer(cols = c(Ptot_load, e_Ptot_load), names_to = "Ptot_type", values_to = "Ptot_value")
plot_data$Ptot_type <- factor(plot_data$Ptot_type, levels = c("Ptot_load", "e_Ptot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ptot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
PSC3 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ptot_value, x = as.numeric(interaction(Ptot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("P"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 0.08), xlim = c(1.2, 23.8)) +
  scale_y_continuous(breaks = seq(0, 5,0.02)) +
  scale_x_continuous(breaks = x_breaks, labels = x_labels) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
PSC3

# Ntot yearly load Site SC3
# Define custom colors and labels for the fill scale
custom_colors <- c("Ntot_load.2"="#E69F00", 
                   "Ntot_load.1"="#0072B2", 
                   "e_Ntot_load.2"="#F0E442", 
                   "e_Ntot_load.1"="#009E73")  # Customize colors
custom_labels <- c("Ntot_load.2" = expression(Q[O]*" and N"[tot~","~O]), 
                   "Ntot_load.1" = expression(Q[E]*" and N"[tot~","~O]), 
                   "e_Ntot_load.2" = expression(Q[O]*" and N"[tot~","~E]), 
                   "e_Ntot_load.1" = expression(Q[E]*" and N"[tot~","~E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "SC3",] %>%
  pivot_longer(cols = c(Ntot_load, e_Ntot_load), names_to = "Ntot_type", values_to = "Ntot_value")
plot_data$Ntot_type <- factor(plot_data$Ntot_type, levels = c("Ntot_load", "e_Ntot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ntot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
NSC3 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ntot_value, x = as.numeric(interaction(Ntot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("N"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 0.9), xlim = c(1.2, 23.8)) +
  scale_y_continuous(breaks = seq(0, 10, 0.2)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  theme(legend.position = "none") +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
NSC3

# DOC yearly load Site SC3
# Define custom colors and labels for the fill scale
custom_colors <- c("DOC_load.2"="#E69F00", 
                   "DOC_load.1"="#0072B2", 
                   "e_DOC_load.2"="#F0E442", 
                   "e_DOC_load.1"="#009E73")  # Customize colors
custom_labels <- c("DOC_load.2" = expression(Q[O]*" and DOC"[M]), 
                   "DOC_load.1" = expression(Q[E]*" and DOC"[M]), 
                   "e_DOC_load.2" = expression(Q[O]*" and DOC"[E]), 
                   "e_DOC_load.1" = expression(Q[E]*" and DOC"[E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "SC3",] %>%
  pivot_longer(cols = c(DOC_load, e_DOC_load), names_to = "DOC_type", values_to = "DOC_value")
plot_data$DOC_type <- factor(plot_data$DOC_type, levels = c("DOC_load", "e_DOC_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$DOC_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
DOCSC3 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = DOC_value, x = as.numeric(interaction(DOC_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = "SC3",
       x = NULL,
       y = expression("DOC load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 60), xlim = c(1.2, 23.8)) +
  scale_y_continuous(breaks = seq(0, 600, 20), labels = scales::number_format(accuracy = 0.1)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  theme(legend.position = "none") +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
DOCSC3

SC3 <- (DOCSC3/NSC3/PSC3)
SC3

# Save the plot using ggsave
ggsave("SC3_yearly_load.tiff", 
       plot = SC3, 
       device = "tiff", 
       width = 3740, height = 4624, dpi = 500, units = "px", bg = "white")


########################################
# Ptot yearly load Site F1
# Define custom colors and labels for the fill scale
custom_colors <- c("Ptot_load.2"="#E69F00", 
                   "Ptot_load.1"="#0072B2", 
                   "e_Ptot_load.2"="#F0E442", 
                   "e_Ptot_load.1"="#009E73") # Customize colors
custom_labels <- c("Ptot_load.2" = "Observed Q and/or runoff concentration", 
                   "Ptot_load.1" = "Estimated frost season Q and runoff concentration", 
                   "e_Ptot_load.2" = "Observed Q and/or regression modeled runoff concentration", 
                   "e_Ptot_load.1" = "Estimated frost season Q and regression modeled runoff concentration")
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F1",] %>%
  pivot_longer(cols = c(Ptot_load, e_Ptot_load), names_to = "Ptot_type", values_to = "Ptot_value")
plot_data$Ptot_type <- factor(plot_data$Ptot_type, levels = c("Ptot_load", "e_Ptot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ptot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
PF1 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ptot_value, x = as.numeric(interaction(Ptot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("P"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 0.25), xlim = c(1.2, 21.8)) +
  scale_y_continuous(breaks = seq(0, 10, 0.05)) +
  scale_x_continuous(breaks = x_breaks, labels = x_labels) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
PF1

# Ntot yearly load Site F1
# Define custom colors and labels for the fill scale
custom_colors <- c("Ntot_load.2"="#E69F00", 
                   "Ntot_load.1"="#0072B2", 
                   "e_Ntot_load.2"="#F0E442", 
                   "e_Ntot_load.1"="#009E73")  # Customize colors
custom_labels <- c("Ntot_load.2" = expression(Q[O]*" and N"[tot~","~O]), 
                   "Ntot_load.1" = expression(Q[E]*" and N"[tot~","~O]), 
                   "e_Ntot_load.2" = expression(Q[O]*" and N"[tot~","~E]), 
                   "e_Ntot_load.1" = expression(Q[E]*" and N"[tot~","~E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F1",] %>%
  pivot_longer(cols = c(Ntot_load, e_Ntot_load), names_to = "Ntot_type", values_to = "Ntot_value")
plot_data$Ntot_type <- factor(plot_data$Ntot_type, levels = c("Ntot_load", "e_Ntot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ntot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
NF1 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ntot_value, x = as.numeric(interaction(Ntot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("N"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 2), xlim = c(1.2, 21.8)) +
  scale_y_continuous(breaks = seq(0, 10, 0.5)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
NF1

# DOC yearly load Site F1
# Define custom colors and labels for the fill scale
custom_colors <- c("DOC_load.2"="#E69F00", 
                   "DOC_load.1"="#0072B2", 
                   "e_DOC_load.2"="#F0E442", 
                   "e_DOC_load.1"="#009E73")  # Customize colors
custom_labels <- c("DOC_load.2" = expression(Q[O]*" and DOC"[M]), 
                   "DOC_load.1" = expression(Q[E]*" and DOC"[M]), 
                   "e_DOC_load.2" = expression(Q[O]*" and DOC"[E]), 
                   "e_DOC_load.1" = expression(Q[E]*" and DOC"[E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F1",] %>%
  pivot_longer(cols = c(DOC_load, e_DOC_load), names_to = "DOC_type", values_to = "DOC_value")
plot_data$DOC_type <- factor(plot_data$DOC_type, levels = c("DOC_load", "e_DOC_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$DOC_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
DOCF1 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = DOC_value, x = as.numeric(interaction(DOC_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = "F1",
       x = NULL,
       y = expression("DOC load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 100), xlim = c(1.2, 21.8)) +
  scale_y_continuous(breaks = seq(0, 600, 20)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
DOCF1

F1 <- (DOCF1/NF1/PF1)
F1

# Save the plot using ggsave
ggsave("F1_yearly_load.tiff", 
       plot = F1, 
       device = "tiff", 
       width = 3740, height = 4624, dpi = 500, units = "px", bg = "white")

########################################
# Ptot yearly load Site F2
# Define custom colors and labels for the fill scale
custom_colors <- c("Ptot_load.2"="#E69F00", 
                   "Ptot_load.1"="#0072B2", 
                   "e_Ptot_load.2"="#F0E442", 
                   "e_Ptot_load.1"="#009E73") # Customize colors
custom_labels <- c("Ptot_load.2" = "Observed Q and/or runoff concentration", 
                   "Ptot_load.1" = "Estimated frost season Q and runoff concentration", 
                   "e_Ptot_load.2" = "Observed Q and/or regression modeled runoff concentration", 
                   "e_Ptot_load.1" = "Estimated frost season Q and regression modeled runoff concentration")
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F2",] %>%
  pivot_longer(cols = c(Ptot_load, e_Ptot_load), names_to = "Ptot_type", values_to = "Ptot_value")
plot_data$Ptot_type <- factor(plot_data$Ptot_type, levels = c("Ptot_load", "e_Ptot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ptot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
PF2 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ptot_value, x = as.numeric(interaction(Ptot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("P"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 0.5), xlim = c(1.2, 21.8)) +
  scale_y_continuous(breaks = seq(0, 10, 0.1)) +
  scale_x_continuous(breaks = x_breaks, labels = x_labels) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
PF2

# Ntot yearly load Site F2
# Define custom colors and labels for the fill scale
custom_colors <- c("Ntot_load.2"="#E69F00", 
                   "Ntot_load.1"="#0072B2", 
                   "e_Ntot_load.2"="#F0E442", 
                   "e_Ntot_load.1"="#009E73")  # Customize colors
custom_labels <- c("Ntot_load.2" = expression(Q[O]*" and N"[tot~","~O]), 
                   "Ntot_load.1" = expression(Q[E]*" and N"[tot~","~O]), 
                   "e_Ntot_load.2" = expression(Q[O]*" and N"[tot~","~E]), 
                   "e_Ntot_load.1" = expression(Q[E]*" and N"[tot~","~E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F2",] %>%
  pivot_longer(cols = c(Ntot_load, e_Ntot_load), names_to = "Ntot_type", values_to = "Ntot_value")
plot_data$Ntot_type <- factor(plot_data$Ntot_type, levels = c("Ntot_load", "e_Ntot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ntot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
NF2 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ntot_value, x = as.numeric(interaction(Ntot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("N"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 3), xlim = c(1.2, 21.8)) +
  scale_y_continuous(breaks = seq(0, 10, 1), labels = scales::number_format(accuracy = 0.1)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
NF2

# DOC yearly load Site F2
# Define custom colors and labels for the fill scale
custom_colors <- c("DOC_load.2"="#E69F00", 
                   "DOC_load.1"="#0072B2", 
                   "e_DOC_load.2"="#F0E442", 
                   "e_DOC_load.1"="#009E73")  # Customize colors
custom_labels <- c("DOC_load.2" = expression(Q[O]*" and DOC"[M]), 
                   "DOC_load.1" = expression(Q[E]*" and DOC"[M]), 
                   "e_DOC_load.2" = expression(Q[O]*" and DOC"[E]), 
                   "e_DOC_load.1" = expression(Q[E]*" and DOC"[E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F2",] %>%
  pivot_longer(cols = c(DOC_load, e_DOC_load), names_to = "DOC_type", values_to = "DOC_value")
plot_data$DOC_type <- factor(plot_data$DOC_type, levels = c("DOC_load", "e_DOC_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$DOC_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
DOCF2 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = DOC_value, x = as.numeric(interaction(DOC_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = "F2",
       x = NULL,
       y = expression("DOC load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 150), xlim = c(1.2, 21.8)) +
  scale_y_continuous(breaks = seq(0, 600, 50)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
DOCF2

F2 <- (DOCF2/NF2/PF2)
F2

# Save the plot using ggsave
ggsave("F2_yearly_load.tiff", 
       plot = F2, 
       device = "tiff", 
       width = 3740, height = 4624, dpi = 500, units = "px", bg = "white")

##########################################
# Ptot yearly load Site FC1
# Define custom colors and labels for the fill scale
custom_colors <- c("Ptot_load.2"="#E69F00", 
                   "Ptot_load.1"="#0072B2", 
                   "e_Ptot_load.2"="#F0E442", 
                   "e_Ptot_load.1"="#009E73") # Customize colors
custom_labels <- c("Ptot_load.2" = "Observed Q and/or runoff concentration", 
                   "Ptot_load.1" = "Estimated frost season Q and runoff concentration", 
                   "e_Ptot_load.2" = "Observed Q and/or regression modeled runoff concentration", 
                   "e_Ptot_load.1" = "Estimated frost season Q and regression modeled runoff concentration")
# Pivot the data for plotting

plot_data <- yearly_load[yearly_load$Site == "FC1",] %>%
  pivot_longer(cols = c(Ptot_load, e_Ptot_load), names_to = "Ptot_type", values_to = "Ptot_value")
plot_data$Ptot_type <- factor(plot_data$Ptot_type, levels = c("Ptot_load", "e_Ptot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ptot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
PFC1 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ptot_value, x = as.numeric(interaction(Ptot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("P"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 0.08), xlim = c(1.2, 25.8)) +
  scale_y_continuous(breaks = seq(0, 5,0.02)) +
  scale_x_continuous(breaks = x_breaks, labels = x_labels) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
PFC1

# Ntot yearly load Site FC1
# Define custom colors and labels for the fill scale
custom_colors <- c("Ntot_load.2"="#E69F00", 
                   "Ntot_load.1"="#0072B2", 
                   "e_Ntot_load.2"="#F0E442", 
                   "e_Ntot_load.1"="#009E73")  # Customize colors
custom_labels <- c("Ntot_load.2" = expression(Q[O]*" and N"[tot~","~O]), 
                   "Ntot_load.1" = expression(Q[E]*" and N"[tot~","~O]), 
                   "e_Ntot_load.2" = expression(Q[O]*" and N"[tot~","~E]), 
                   "e_Ntot_load.1" = expression(Q[E]*" and N"[tot~","~E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "FC1",] %>%
  pivot_longer(cols = c(Ntot_load, e_Ntot_load), names_to = "Ntot_type", values_to = "Ntot_value")
plot_data$Ntot_type <- factor(plot_data$Ntot_type, levels = c("Ntot_load", "e_Ntot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ntot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
NFC1 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ntot_value, x = as.numeric(interaction(Ntot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("N"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 2.5), xlim = c(1.2, 25.8)) +
  scale_y_continuous(breaks = seq(0, 10, 0.5)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
NFC1

# DOC yearly load Site FC1
# Define custom colors and labels for the fill scale
custom_colors <- c("DOC_load.2"="#E69F00", 
                   "DOC_load.1"="#0072B2", 
                   "e_DOC_load.2"="#F0E442", 
                   "e_DOC_load.1"="#009E73")  # Customize colors
custom_labels <- c("DOC_load.2" = expression(Q[O]*" and DOC"[M]), 
                   "DOC_load.1" = expression(Q[E]*" and DOC"[M]), 
                   "e_DOC_load.2" = expression(Q[O]*" and DOC"[E]), 
                   "e_DOC_load.1" = expression(Q[E]*" and DOC"[E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "FC1",] %>%
  pivot_longer(cols = c(DOC_load, e_DOC_load), names_to = "DOC_type", values_to = "DOC_value")
plot_data$DOC_type <- factor(plot_data$DOC_type, levels = c("DOC_load", "e_DOC_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$DOC_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
DOCFC1 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = DOC_value, x = as.numeric(interaction(DOC_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = "FC1",
       x = NULL,
       y = expression("DOC load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 150), xlim = c(1.2, 25.8)) +
  scale_y_continuous(breaks = seq(0, 600, 50)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
DOCFC1

FC1 <- (DOCFC1/NFC1/PFC1)
FC1

# Save the plot using ggsave
ggsave("FC1_yearly_load.tiff", 
       plot = FC1, 
       device = "tiff", 
       width = 3740, height = 4624, dpi = 500, units = "px", bg = "white")

########################################
# Ptot yearly load Site F5
# Define custom colors and labels for the fill scale
custom_colors <- c("Ptot_load.2"="#E69F00", 
                   "Ptot_load.1"="#0072B2", 
                   "e_Ptot_load.2"="#F0E442", 
                   "e_Ptot_load.1"="#009E73") # Customize colors
custom_labels <- c("Ptot_load.2" = "Observed Q and/or runoff concentration", 
                   "Ptot_load.1" = "Estimated frost season Q and runoff concentration", 
                   "e_Ptot_load.2" = "Observed Q and/or regression modeled runoff concentration", 
                   "e_Ptot_load.1" = "Estimated frost season Q and regression modeled runoff concentration")
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F5",] %>%
  pivot_longer(cols = c(Ptot_load, e_Ptot_load), names_to = "Ptot_type", values_to = "Ptot_value")
plot_data$Ptot_type <- factor(plot_data$Ptot_type, levels = c("Ptot_load", "e_Ptot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ptot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
PF5 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ptot_value, x = as.numeric(interaction(Ptot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("P"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 0.4), xlim = c(1.2, 19.8)) +
  scale_y_continuous(breaks = seq(0, 10, 0.1), labels = scales::number_format(accuracy = 0.01)) +
  scale_x_continuous(breaks = x_breaks, labels = x_labels) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
PF5

# Ntot yearly load Site F5
# Define custom colors and labels for the fill scale
custom_colors <- c("Ntot_load.2"="#E69F00", 
                   "Ntot_load.1"="#0072B2", 
                   "e_Ntot_load.2"="#F0E442", 
                   "e_Ntot_load.1"="#009E73")  # Customize colors
custom_labels <- c("Ntot_load.2" = expression(Q[O]*" and N"[tot~","~O]), 
                   "Ntot_load.1" = expression(Q[E]*" and N"[tot~","~O]), 
                   "e_Ntot_load.2" = expression(Q[O]*" and N"[tot~","~E]), 
                   "e_Ntot_load.1" = expression(Q[E]*" and N"[tot~","~E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F5",] %>%
  pivot_longer(cols = c(Ntot_load, e_Ntot_load), names_to = "Ntot_type", values_to = "Ntot_value")
plot_data$Ntot_type <- factor(plot_data$Ntot_type, levels = c("Ntot_load", "e_Ntot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ntot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
NF5 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ntot_value, x = as.numeric(interaction(Ntot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("N"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 4), xlim = c(1.2, 19.8)) +
  scale_y_continuous(breaks = seq(0, 10, 1), labels = scales::number_format(accuracy = 0.1)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
NF5

# DOC yearly load Site F5
# Define custom colors and labels for the fill scale
custom_colors <- c("DOC_load.2"="#E69F00", 
                   "DOC_load.1"="#0072B2", 
                   "e_DOC_load.2"="#F0E442", 
                   "e_DOC_load.1"="#009E73")  # Customize colors
custom_labels <- c("DOC_load.2" = expression(Q[O]*" and DOC"[M]), 
                   "DOC_load.1" = expression(Q[E]*" and DOC"[M]), 
                   "e_DOC_load.2" = expression(Q[O]*" and DOC"[E]), 
                   "e_DOC_load.1" = expression(Q[E]*" and DOC"[E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F5",] %>%
  pivot_longer(cols = c(DOC_load, e_DOC_load), names_to = "DOC_type", values_to = "DOC_value")
plot_data$DOC_type <- factor(plot_data$DOC_type, levels = c("DOC_load", "e_DOC_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$DOC_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
DOCF5 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = DOC_value, x = as.numeric(interaction(DOC_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = "F5",
       x = NULL,
       y = expression("DOC load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 150), xlim = c(1.2, 19.8)) +
  scale_y_continuous(breaks = seq(0, 600, 50)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  geom_vline(xintercept = 6.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
DOCF5

F5 <- (DOCF5/NF5/PF5)
F5

# Save the plot using ggsave
ggsave("F5_yearly_load.tiff", 
       plot = F5, 
       device = "tiff", 
       width = 3740, height = 4624, dpi = 500, units = "px", bg = "white")

##########################################
# Ptot yearly load Site FC5
# Define custom colors and labels for the fill scale
custom_colors <- c("Ptot_load.2"="#E69F00", 
                   "Ptot_load.1"="#0072B2", 
                   "e_Ptot_load.2"="#F0E442", 
                   "e_Ptot_load.1"="#009E73") # Customize colors
custom_labels <- c("Ptot_load.2" = "Observed Q and/or runoff concentration", 
                   "Ptot_load.1" = "Estimated frost season Q and runoff concentration", 
                   "e_Ptot_load.2" = "Observed Q and/or regression modeled runoff concentration", 
                   "e_Ptot_load.1" = "Estimated frost season Q and regression modeled runoff concentration")
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "FC5",] %>%
  pivot_longer(cols = c(Ptot_load, e_Ptot_load), names_to = "Ptot_type", values_to = "Ptot_value")
plot_data$Ptot_type <- factor(plot_data$Ptot_type, levels = c("Ptot_load", "e_Ptot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ptot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
PFC5 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ptot_value, x = as.numeric(interaction(Ptot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("P"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 0.07), xlim = c(1.2, 19.8)) +
  scale_y_continuous(breaks = seq(0, 5,0.02)) +
  scale_x_continuous(breaks = x_breaks, labels = x_labels) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
PFC5

# Ntot yearly load Site FC5
# Define custom colors and labels for the fill scale
custom_colors <- c("Ntot_load.2"="#E69F00", 
                   "Ntot_load.1"="#0072B2", 
                   "e_Ntot_load.2"="#F0E442", 
                   "e_Ntot_load.1"="#009E73")  # Customize colors
custom_labels <- c("Ntot_load.2" = expression(Q[O]*" and N"[tot~","~O]), 
                   "Ntot_load.1" = expression(Q[E]*" and N"[tot~","~O]), 
                   "e_Ntot_load.2" = expression(Q[O]*" and N"[tot~","~E]), 
                   "e_Ntot_load.1" = expression(Q[E]*" and N"[tot~","~E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "FC5",] %>%
  pivot_longer(cols = c(Ntot_load, e_Ntot_load), names_to = "Ntot_type", values_to = "Ntot_value")
plot_data$Ntot_type <- factor(plot_data$Ntot_type, levels = c("Ntot_load", "e_Ntot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ntot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
NFC5 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ntot_value, x = as.numeric(interaction(Ntot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("N"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 2), xlim = c(1.2, 19.8)) +
  scale_y_continuous(breaks = seq(0, 10, 0.5)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
NFC5

# DOC yearly load Site FC5
# Define custom colors and labels for the fill scale
custom_colors <- c("DOC_load.2"="#E69F00", 
                   "DOC_load.1"="#0072B2", 
                   "e_DOC_load.2"="#F0E442", 
                   "e_DOC_load.1"="#009E73")  # Customize colors
custom_labels <- c("DOC_load.2" = expression(Q[O]*" and DOC"[M]), 
                   "DOC_load.1" = expression(Q[E]*" and DOC"[M]), 
                   "e_DOC_load.2" = expression(Q[O]*" and DOC"[E]), 
                   "e_DOC_load.1" = expression(Q[E]*" and DOC"[E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "FC5",] %>%
  pivot_longer(cols = c(DOC_load, e_DOC_load), names_to = "DOC_type", values_to = "DOC_value")
plot_data$DOC_type <- factor(plot_data$DOC_type, levels = c("DOC_load", "e_DOC_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$DOC_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
DOCFC5 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = DOC_value, x = as.numeric(interaction(DOC_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = "FC5",
       x = NULL,
       y = expression("DOC load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 100), xlim = c(1.2, 19.8)) +
  scale_y_continuous(breaks = seq(0, 600, 20)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
DOCFC5

FC5 <- (DOCFC5/NFC5/PFC5)
FC5

# Save the plot using ggsave
ggsave("FC5_yearly_load.tiff", 
       plot = FC5, 
       device = "tiff", 
       width = 3740, height = 4624, dpi = 500, units = "px", bg = "white")

########################################
# Ptot yearly load Site F11/1
# Define custom colors and labels for the fill scale
custom_colors <- c("Ptot_load.2"="#E69F00", 
                   "Ptot_load.1"="#0072B2", 
                   "e_Ptot_load.2"="#F0E442", 
                   "e_Ptot_load.1"="#009E73") # Customize colors
custom_labels <- c("Ptot_load.2" = "Observed Q and/or runoff concentration", 
                   "Ptot_load.1" = "Estimated frost season Q and runoff concentration", 
                   "e_Ptot_load.2" = "Observed Q and/or regression modeled runoff concentration", 
                   "e_Ptot_load.1" = "Estimated frost season Q and regression modeled runoff concentration")
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F11/1",] %>%
  pivot_longer(cols = c(Ptot_load, e_Ptot_load), names_to = "Ptot_type", values_to = "Ptot_value")
plot_data$Ptot_type <- factor(plot_data$Ptot_type, levels = c("Ptot_load", "e_Ptot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ptot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
PF11_1 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ptot_value, x = as.numeric(interaction(Ptot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("P"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 0.2), xlim = c(1.2, 25.8)) +
  scale_y_continuous(breaks = seq(0, 10, 0.05)) +
  scale_x_continuous(breaks = x_breaks, labels = x_labels) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  geom_vline(xintercept = 8.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
PF11_1

# Ntot yearly load Site F11/1
# Define custom colors and labels for the fill scale
custom_colors <- c("Ntot_load.2"="#E69F00", 
                   "Ntot_load.1"="#0072B2", 
                   "e_Ntot_load.2"="#F0E442", 
                   "e_Ntot_load.1"="#009E73")  # Customize colors
custom_labels <- c("Ntot_load.2" = expression(Q[O]*" and N"[tot~","~O]), 
                   "Ntot_load.1" = expression(Q[E]*" and N"[tot~","~O]), 
                   "e_Ntot_load.2" = expression(Q[O]*" and N"[tot~","~E]), 
                   "e_Ntot_load.1" = expression(Q[E]*" and N"[tot~","~E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F11/1",] %>%
  pivot_longer(cols = c(Ntot_load, e_Ntot_load), names_to = "Ntot_type", values_to = "Ntot_value")
plot_data$Ntot_type <- factor(plot_data$Ntot_type, levels = c("Ntot_load", "e_Ntot_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$Ntot_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
NF11_1 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = Ntot_value, x = as.numeric(interaction(Ntot_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = NULL,
       x = NULL,
       y = expression("N"[tot]*" load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 6), xlim = c(1.2, 25.8)) +
  scale_y_continuous(breaks = seq(0, 10, 2), labels = scales::number_format(accuracy = 0.1)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow = 4, byrow = TRUE)) +
  theme(legend.position = "none") +
  geom_vline(xintercept = 8.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels) 
NF11_1

# DOC yearly load Site F11/1
# Define custom colors and labels for the fill scale
custom_colors <- c("DOC_load.2"="#E69F00", 
                   "DOC_load.1"="#0072B2", 
                   "e_DOC_load.2"="#F0E442", 
                   "e_DOC_load.1"="#009E73")  # Customize colors
custom_labels <- c("DOC_load.2" = expression(Q[O]*" and c"[M]), 
                   "DOC_load.1" = expression(Q[E]*" and c"[M]), 
                   "e_DOC_load.2" = expression(Q[O]*" and c"[E]), 
                   "e_DOC_load.1" = expression(Q[E]*" and c"[E]))
# Pivot the data for plotting
plot_data <- yearly_load[yearly_load$Site == "F11/1",] %>%
  pivot_longer(cols = c(DOC_load, e_DOC_load), names_to = "DOC_type", values_to = "DOC_value")
plot_data$DOC_type <- factor(plot_data$DOC_type, levels = c("DOC_load", "e_DOC_load"))
x_labels <- levels(factor(plot_data$Cal_year))
# Create a x-axis break vector
x_breaks <- as.numeric(seq(1.5, 2*length(levels(factor(plot_data$Cal_year))) + 0.5, by = 2))
# Reorder the levels of the interaction variable to match the custom_labels order
plot_data$fill_type <- interaction(plot_data$DOC_type, plot_data$Season)
plot_data$fill_type <- factor(plot_data$fill_type, 
                              levels = names(custom_labels))
# Plot
DOCF11_1 <- ggplot() + 
  geom_col(data = plot_data, 
           aes(y = DOC_value, x = as.numeric(interaction(DOC_type, Cal_year)), 
               fill = fill_type), position = "stack", width = 0.8, color = "black") +
  custom_theme +
  labs(title = "F11/1",
       x = NULL,
       y = expression("DOC load (kg ha"^-1*" yr"^-1*")")) +
  coord_cartesian(ylim = c(0, 350), xlim = c(1.2, 25.8)) +
  scale_y_continuous(breaks = seq(0, 600, 100)) +
  scale_x_continuous(breaks = x_breaks, labels = NULL) +
  guides(fill = guide_legend(nrow=1, byrow = TRUE)) +
  theme(legend.position = "none") +
  geom_vline(xintercept = 8.5, color = "#E31A1C", linetype = "solid", linewidth = 0.8) +
  scale_fill_manual(values = custom_colors, labels = custom_labels)
DOCF11_1

F11_1 <- (DOCF11_1/NF11_1/PF11_1)
F11_1

# Save the plot using ggsave
ggsave("F11_1_yearly_load.tiff", 
       plot = F11_1, 
       device = "tiff", 
       width = 3740, height = 4624, dpi = 500, units = "px", bg = "white")
