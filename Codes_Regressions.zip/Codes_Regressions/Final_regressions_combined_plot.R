library(dplyr) # Data handling
library(lubridate) # Date and time handling
library(segmented) # Segmented regression analysis
library(Hmisc)

# Set working directory
setwd("C:/Users/lpakkila/OneDrive - University of Oulu and Oamk/Lassin väitöskirjatyö/Peatland water table and quality/Water_quality/Porewater_vs_runoff_quality/")

# Pull and treat data 
regres <- read.csv('porewater_and_runoff_quality_regression_V2.csv', 
                   header=TRUE, sep =";", quote="", dec=".", fill=TRUE, comment.char="", skipNul=FALSE)
regres$peatland <- as.numeric(regres$peatland)
regres$date <- dmy(regres$date, tz=NULL)
regres$p_pH <- as.numeric(regres$p_pH)
regres$fyear <- as.numeric(regres$fyear)
regres$r_NO23N_ug_l <- as.numeric(regres$r_NO23N_ug_l)
regres$r_SS_mg_l <- as.numeric(regres$r_SS_mg_l)
regres$r_Fe_ug_l <- as.numeric(regres$r_Fe_ug_l)
regres$p_tot_N_ug_l <- as.numeric(regres$p_tot_N_ug_l)


# Add period column to restored dataset
regres$period <- NA
regres$period[regres$fyear < 0] <- "<0"
regres$period[regres$fyear >=0 & regres$fyear <= 3] <- "0-3"
regres$period[regres$fyear >3] <- ">3"
regres$period[regres$res_pris == 2] <- "Pristine"
regres$period <- as.factor(regres$period)

# Store current levels
existing_levels <- levels(regres$period)
# Add level Outlier
regres$period <- factor(regres$period, levels = c(existing_levels, "Outlier", "Outlier_03", "Outlier_3"))
# Add a calendar year column
regres$year <- NA
regres$year <- as.factor(format(regres$date,'%Y'))

# Divide dataset into restored and pristine
regres_p <- regres[regres$period == "Pristine", ]
regres_r <- regres[regres$res_pris == 1 & regres$period != "<0", ]
regres_d <- regres[regres$period == "<0", ]

# Colors and shapes
colors <- c("0-3 restored" = "coral2", ">3 restored" = "#7570B3", "Drained" = "#222255", "Pristine" = "#27462C")
shapes <- c("0-3 restored" = 1, ">3 restored" = 2, "Drained" = 6, "Pristine" = 0)

#### DOC

### RESTORED DOC 
# Linear and segmented regression
# 0-3 years after restoration
regres_rC <- regres_r
regres_rC$period[regres_rC$period == "0-3" & regres_rC$p_DOC_mg_l >= 100] <- "Outlier"
# Count of datapoints n for periods
nC_03 <- min(sum(!is.na(regres_rC$r_DOC_mg_l[regres_rC$period == "0-3"])), 
             sum(!is.na(regres_rC$p_DOC_mg_l[regres_rC$period == "0-3"])))
nC_03Outl <- min(sum(!is.na(regres_rC$r_DOC_mg_l[regres_rC$period == "Outlier"])), 
               sum(!is.na(regres_rC$p_DOC_mg_l[regres_rC$period == "Outlier"])))
# Perform the linear regression
Cfit_03 <- lm(r_DOC_mg_l ~ p_DOC_mg_l, data = subset(regres_rC, period == "0-3" & p_DOC_mg_l < 100))
# Test linear regression for break points 
pscore.test(Cfit_03)
# Predict with linear regression
C_int03 <- predict(Cfit_03, data.frame(p_DOC_mg_l = seq(0, 180, length.out = 100)), se = TRUE)

# Over 3 years after restoration
Cfit_3 <- lm(r_DOC_mg_l ~ p_DOC_mg_l, data = subset(regres_rC, period == ">3"))
# Count of datapoints n for periods
nC_3 <- min(sum(!is.na(regres_rC$r_DOC_mg_l[regres_rC$period == ">3"])), 
             sum(!is.na(regres_rC$p_DOC_mg_l[regres_rC$period == ">3"])))
# Test linear regression for break points 
pscore.test(Cfit_3)
# Perform segmented regression
Cseg_3 <- segmented(Cfit_3, seg.Z = ~p_DOC_mg_l, npsi = 1)

### DRAINED DOC 
# Linear regression
Cfit_dr <- lm(r_DOC_mg_l ~ p_DOC_mg_l, data = regres_d)
# Count of datapoints n for periods
nC_dr <- min(sum(!is.na(regres_d$r_DOC_mg_l)), 
            sum(!is.na(regres_d$p_DOC_mg_l)))
# Test linear regression for break points 
pscore.test(Cfit_dr)
# Predict with linear regression
C_int_dr <- predict(Cfit_dr, data.frame(p_DOC_mg_l = seq(0, 180, length.out = 100)), se = TRUE)

### PRISTINE DOC 
#Linear regression
regres_pC <- regres_p
regres_pC$period[c(49,32,65)] <- "Outlier"
# Count of datapoints n for periods
nC_pr <- min(sum(!is.na(regres_pC$r_DOC_mg_l[regres_pC$period == "Pristine"])), 
             sum(!is.na(regres_pC$p_DOC_mg_l[regres_pC$period == "Pristine"])))
nC_prOutl <- min(sum(!is.na(regres_pC$r_DOC_mg_l[regres_pC$period == "Outlier"])), 
             sum(!is.na(regres_pC$p_DOC_mg_l[regres_pC$period == "Outlier"])))
# Perform the linear regression
Cfit_pr <- lm(r_DOC_mg_l ~ p_DOC_mg_l + I(p_DOC_mg_l^2), data = subset(regres_pC, period == "Pristine"))
# Test linear regression for break points 
pscore.test(Cfit_pr)
# Predict with linear regression
C_int_pr <- predict(Cfit_pr, data.frame(p_DOC_mg_l = seq(0, 180, length.out = 100)), se = TRUE)


#### Ntot

### RESTORED Ntot 
# Segmented regression
# 0-3 years after restoration
# Perform the linear regression
Nfit_03 <- lm(r_tot_N_ug_l ~ p_tot_N_ug_l, data = subset(regres_r, period == "0-3"))
# Count of datapoints n for periods
nN_03 <- min(sum(!is.na(regres_r$r_tot_N_ug_l[regres_r$period == "0-3"])), 
             sum(!is.na(regres_r$p_tot_N_ug_l[regres_r$period == "0-3"])))
# Test linear regression for break points 
pscore.test(Nfit_03)
# Perform segmented regression
Nseg_03 <- segmented(Nfit_03, seg.Z = ~p_tot_N_ug_l, npsi = 1)

# Over 3 years after restoration
Nfit_3 <- lm(r_tot_N_ug_l ~ p_tot_N_ug_l, data = subset(regres_r, period == ">3"))
# Count of datapoints n for periods
nN_3 <- min(sum(!is.na(regres_r$r_tot_N_ug_l[regres_r$period == ">3"])), 
             sum(!is.na(regres_r$p_tot_N_ug_l[regres_r$period == ">3"])))
# Test linear regression for break points 
pscore.test(Nfit_3)
# Perform segmented regression
Nseg_3 <- segmented(Nfit_3, seg.Z = ~p_tot_N_ug_l, npsi = 1)

### DRAINED Ntot 
# Segmented regression
# Perform the linear regression
Nfit_dr <- lm(r_tot_N_ug_l ~ p_tot_N_ug_l, data = regres_d)
# Count of datapoints n for periods
nN_dr <- min(sum(!is.na(regres_d$r_tot_N_ug_l)), 
             sum(!is.na(regres_d$p_tot_N_ug_l)))
# Test linear regression for break points 
pscore.test(Nfit_dr)
# Perform segmented regression
Nseg_dr <- segmented(Nfit_dr, seg.Z = ~p_tot_N_ug_l, npsi = 1)

### PRISTINE Ntot 
# Linear regression
regres_pN <- regres_p 
regres_pN$period[c(1,49)] <- "Outlier"
# Perform the linear regression
Nfit_pr <- lm(r_tot_N_ug_l ~ p_tot_N_ug_l, data = subset(regres_pN, period == "Pristine"))
# Count of datapoints n for periods
nN_pr <- min(sum(!is.na(regres_pN$r_tot_N_ug_l[regres_pN$period == "Pristine"])), 
             sum(!is.na(regres_pN$p_tot_N_ug_l[regres_pN$period == "Pristine"])))
nN_prOutl <- min(sum(!is.na(regres_pN$r_tot_N_ug_l[regres_pN$period == "Outlier"])), 
                 sum(!is.na(regres_pN$p_tot_N_ug_l[regres_pN$period == "Outlier"])))
# Test linear regression for break points
pscore.test(Nfit_pr)
# Predict with linear regression
N_int_pr <- predict(Nfit_pr, data.frame(p_tot_N_ug_l = seq(0, 7000, length.out = 100)), se = TRUE)

#### Ptot

### RESTORED Ptot 
## 0-3 years after restoration
regres_rP <- regres_r
regres_rP$period[regres_rP$period == "0-3" & regres_rP$p_tot_P_ug_l >= 100] <- "Outlier_03"
regres_rP$period[regres_rP$period == ">3" & regres_rP$p_tot_P_ug_l >= 700] <- "Outlier_3"
# Perform the linear regression
Pfit_03 <- lm(r_tot_P_ug_l ~ p_tot_P_ug_l, data=subset(regres_rP, period == "0-3"))
# Count of datapoints n for periods
nP_03 <- min(sum(!is.na(regres_rP$r_tot_P_ug_l[regres_rP$period == "0-3"])), 
             sum(!is.na(regres_rP$p_tot_P_ug_l[regres_rP$period == "0-3"])))
nP_03Outl <- min(sum(!is.na(regres_rP$r_tot_P_ug_l[regres_rP$period == "Outlier_03"])), 
                 sum(!is.na(regres_rP$p_tot_P_ug_l[regres_rP$period == "Outlier_03"])))
# Test linear regression for break points 
pscore.test((Pfit_03))
# Predict with linear regression
P_int03 <- predict(Pfit_03, data.frame(p_tot_P_ug_l = seq(0, 1500, length.out = 100)), se = TRUE)

## Over 3 years after restoration
Pfit_3 <- lm(r_tot_P_ug_l ~ p_tot_P_ug_l, data = subset(regres_rP, period == ">3"))
# Count of datapoints n for periods
nP_3 <- min(sum(!is.na(regres_rP$r_tot_P_ug_l[regres_rP$period == ">3"])), 
             sum(!is.na(regres_rP$p_tot_P_ug_l[regres_rP$period == ">3"])))
nP_3Outl <- min(sum(!is.na(regres_rP$r_tot_P_ug_l[regres_rP$period == "Outlier_3"])), 
                 sum(!is.na(regres_rP$p_tot_P_ug_l[regres_rP$period == "Outlier_3"])))
# Test linear regression for break points 
pscore.test(Pfit_3)
# Predict with linear regression
P_int3 <- predict(Pfit_3, data.frame(p_tot_P_ug_l = seq(0, 1500, length.out = 100)), se = TRUE)

### DRAINED Ptot
# Perform the linear regression
Pfit_dr <- lm(r_tot_P_ug_l ~ p_tot_P_ug_l, data = regres_d)
# Count of datapoints n for periods
nP_dr <- min(sum(!is.na(regres_d$r_tot_P_ug_l)), 
             sum(!is.na(regres_d$p_tot_P_ug_l)))
# Test linear regression for break points 
pscore.test(Pfit_dr)
# Perform segmented regression
Pseg_dr <- segmented(Pfit_dr, seg.Z = ~p_tot_P_ug_l, npsi = 1)

### PRISTINE Ptot
regres_pP <- regres_p
regres_pP$period[regres_pP$p_tot_P_ug_l >= 400] <- "Outlier"
# Perform the linear regression
Pfit_pr <- lm(r_tot_P_ug_l ~ p_tot_P_ug_l, data = subset(regres_pP, period == "Pristine" & p_tot_P_ug_l < 400))
# Count of datapoints n for periods
nP_pr <- min(sum(!is.na(regres_pP$r_tot_P_ug_l[regres_pP$period == "Pristine"])), 
             sum(!is.na(regres_pP$p_tot_P_ug_l[regres_pP$period == "Pristine"])))
nP_prOutl <- min(sum(!is.na(regres_pP$r_tot_P_ug_l[regres_pP$period == "Outlier"])), 
                 sum(!is.na(regres_pP$p_tot_P_ug_l[regres_pP$period == "Outlier"])))
# Test linear regression for break points
pscore.test(Pfit_pr)
# Predict with linear regression
P_int_pr <- predict(Pfit_pr, data.frame(p_tot_P_ug_l = seq(0, 850, length.out = 100)), se = TRUE)


#### Plotting
# Start saving engine with the tiff() function (adjust parameters)
tiff(
  file = paste("Test_combined", ".tiff", sep = ""),
  width = 3740,  # Adjust the width to accommodate 3 plots
  height = 4300, # Height remains the same
  units = "px",  # Specify units in pixels
  res = 500      # Set the desired DPI to 500
)

# Define layout: 3 rows, 3 columns with unequal row heights
layout(matrix(1:9, nrow = 3, byrow = TRUE), heights = c(1.32, 1, 1), widths = c(1.07, 1, 1))  # Increase height of first row

# Set margin c(bottom, left, top, right) and adjust mgp c(axis labels, tickmark labels, tickmarks) 
par(mar = c(5, 5, 11.5, 1),  mgp = c(2.4, 0.6, 0), mex = 0.6)

# Set the cex parameters to control the font sizes
par(cex.lab = 1.2,   # Axis labels (similar to ggplot2 size 10)
    cex.axis = 1.2)  # Tick mark labels (similar to ggplot2 size 10)

### Plot 1: Restored DOC

# Color selection for restored DOC
colors_restored <- c("#7570B3", "coral2","coral2","#7570B3")
shapes_restored <- c(1, 2, 4, 4) 

# Plot for restored DOC
plot(r_DOC_mg_l ~ p_DOC_mg_l, regres_rC,
     col = colors_restored[factor(period)], 
     pch = shapes_restored[factor(period)], cex = 1.2,
     ylim = c(0, 180), xlim = c(0, 180),
     ylab = "Runoff DOC, mg/l", 
     xlab = "Porewater DOC, mg/l")

# Add the title separately and adjust its position
title(main = "Restored", line = 9.5, cex.main = 1.5)  # Adjust the 'line' parameter to move it up/down
minor.tick(nx = 2, ny = 2, tick.ratio = 0.5)

# Plot linear regression and confidence intervals
lines(seq(0, 180, length.out = 100), C_int03$fit, col = "coral2", lwd = 2, lty = 2)
polygon(c(seq(0, 180, length.out = 100), rev(seq(0, 180, length.out = 100))),
        c(C_int03$fit + 1.96 * C_int03$se.fit, rev(C_int03$fit - 1.96 * C_int03$se.fit)),
        col = rgb(0.7, 0.7, 0.7, 0.2), border = NA)
plot(Cseg_3, add = TRUE, conf.level = 0.95, shade = TRUE, col = "#7570B3")

# Set xpd=TRUE to allow plotting outside the plot region
par(xpd=TRUE)

# Legend with point shapes and line markers side by side
legend("top", 
       legend = c("0-3 years after restoration", ">3 years after restoration", "Outlier", "Outlier"), 
       col = c("coral2", "#7570B3", "coral2", "#7570B3"), 
       pch = c(2, 1, 4, 4),  # Point shapes
       bty = "n", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = FALSE,  
       inset = c(0, -0.35))

# Add a legend inside the plot with count of datapoints n
legend("topleft", 
       legend = c(paste0("n = ", nC_03),
                  paste0("n = ", nC_3),
                  paste0("n = ", nC_03Outl)), 
       col = c("coral2", 
               "#7570B3",
               "coral2"), 
       pch = c(2,1,4), 
       bty = "o", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F , 
       inset = c(0,0))

### Plot 2: Drained DOC

# Set margin c(bottom, left, top, right) and adjust mgp c(axis labels, tickmark labels, tickmarks) 
par(mar = c(5, 3, 11.5, 1))

# Set xpd=FALSE to deny plotting outside the plot region
par(xpd=FALSE)

# Plot for drained DOC
plot(r_DOC_mg_l ~ p_DOC_mg_l, regres_d,
     col = "#222255", 
     pch = 6, cex = 1.2,
     ylim = c(0, 180), xlim = c(0, 180),
     ylab = "",
     xlab = "Porewater DOC, mg/l")

# Add the title separately and adjust its position
title(main = "Drained", line = 9.5, cex.main = 1.5)
minor.tick(nx = 2, ny = 2, tick.ratio = 0.5)
lines(seq(0, 180, length.out = 100), C_int_dr$fit, col = "#222255", lwd = 2)
polygon(c(seq(0, 180, length.out = 100), rev(seq(0, 180, length.out = 100))),
        c(C_int_dr$fit + 1.96 * C_int_dr$se.fit, rev(C_int_dr$fit - 1.96 * C_int_dr$se.fit)),
        col = rgb(0.7, 0.7, 0.7, 0.2), border = NA)

# Set xpd=TRUE to allow plotting outside the plot region
par(xpd=TRUE)

# Add the legend outside the plot area, below the title
legend("top", 
       legend = c("Drained"), 
       col = c("#222255"), 
       pch = c(6),
       bty = "n", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F, 
       inset = c(0, -0.35))

# Add a legend inside the plot with count of datapoints n
legend("topright", 
       legend = paste0("n = ", nC_dr), 
       col = c("#222255"), 
       pch = c(6), 
       bty = "0", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F, 
       inset = c(0,0))


### Plot 3: Pristine DOC

# Set xpd=FALSE to deny plotting outside the plot region
par(xpd=FALSE)

# Color and shapes selection for pristine DOC
colors_pristine <- c("#27462C", "#27462C") # Pristine and outlier
shapes_pristine <- c(0, 4) # Pristine and outlier

# Plot for pristine DOC
plot(r_DOC_mg_l ~ p_DOC_mg_l, regres_pC,
     col = colors_pristine[factor(period)], 
     pch = shapes_pristine[factor(period)], cex = 1.2,
     ylim = c(0, 180), xlim = c(0, 180),
     ylab = "",
     xlab = "Porewater DOC, mg/l")

# Add the title separately and adjust its position
title(main = "Pristine", line = 9.5, cex.main = 1.5)
minor.tick(nx = 2, ny = 2, tick.ratio = 0.5)
lines(seq(0, 180, length.out = 100), C_int_pr$fit, col = "#27462C", lwd = 2)
polygon(c(seq(0, 180, length.out = 100), rev(seq(0, 180, length.out = 100))),
        c(C_int_pr$fit + 1.96 * C_int_pr$se.fit, rev(C_int_pr$fit - 1.96 * C_int_pr$se.fit)),
        col = rgb(0.7, 0.7, 0.7, 0.2), border = NA)

# Set xpd=TRUE to allow plotting outside the plot region
par(xpd=TRUE)

# Add the legend outside the plot area, below the title
legend("top", 
       legend = c("Pristine","Outlier"), 
       col = c("#27462C", # Pristine
               "#27462C"), 
       pch = c(0,4),
       bty = "n", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F , 
       inset = c(0, -0.35))

# Add the legend outside the plot area, below the title
legend("topright", 
       legend = c(paste0("n = ", nC_pr),
                  paste0("n = ", nC_prOutl)), 
       col = c("#27462C", # Pristine
               "#27462C"), 
       pch = c(0,4), 
       bty = "o", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F , 
       inset = c(0,0))


### Plot 4: Restored Ntot

# Set margin c(bottom, left, top, right) and adjust mgp c(axis labels, tickmark labels, tickmarks) 
par(mar = c(5, 5, 0.5, 1))

# Set xpd=false to deny plotting outside the plot region
par(xpd=FALSE)

# Plot
plot(r_tot_N_ug_l ~ p_tot_N_ug_l, regres_r,
     col = colors_restored[factor(period)], 
     pch = shapes_restored[factor(period)], cex = 1.2,
     ylim = c(0,2700), xlim = c(0,7000),
     ylab = expression("Runoff N"[tot]*", \u03BCg/l"), 
     xlab = expression("Porewater N"[tot]*", \u03BCg/l"))

# Add additional plot elements (ticks, lines, etc.)
minor.tick(nx = 2, ny = 2, tick.ratio = 0.5)

#Segmented regression lines
plot(Nseg_03, add = T, conf.level = 0.95, shade = T, col = "coral2", lty = 2)
plot(Nseg_3, add = T, conf.level = 0.95, shade = T, col = "#7570B3")

# Add a legend inside the plot with count of datapoints n
legend("bottomright", 
       legend = c(paste0("n = ", nN_03),
                  paste0("n = ", nN_3)), 
       col = c("coral2", 
               "#7570B3"), 
       pch = c(2,1), 
       bty = "o", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F , 
       inset = c(0,0))

### Plot 5: Drained Ntot

# Set margin c(bottom, left, top, right) and adjust mgp c(axis labels, tickmark labels, tickmarks) 
par(mar = c(5, 3, 0.5, 1))

# Plot
plot(r_tot_N_ug_l ~ p_tot_N_ug_l, regres_d,
     col = "#222255", 
     pch = 6, cex = 1.2,
     ylim = c(0,2700), xlim = c(0,7000),
     ylab = "", 
     xlab = expression("Porewater N"[tot]*", \u03BCg/l"))

# Add additional plot elements (ticks, lines, etc.)
minor.tick(nx = 2, ny = 2, tick.ratio = 0.5)

# Segmented regression lines
plot(Nseg_dr, add = T, conf.level = 0.95, shade = T, col = "#222255")

# Add a legend inside the plot with count of datapoints n
legend("topright", 
       legend = paste0("n = ", nN_dr), 
       col = c("#222255"), 
       pch = c(6), 
       bty = "0", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F, 
       inset = c(0,0))

### Plot 6: Pristine Ntot

# Create the plot
plot(r_tot_N_ug_l ~ p_tot_N_ug_l, regres_pN,
     col = colors_pristine[factor(period)], 
     pch = shapes_pristine[factor(period)], cex = 1.2,
     ylim = c(0,2700), xlim = c(0,7000),
     ylab = "", 
     xlab = expression("Porewater N"[tot]*", \u03BCg/l"))

# Add additional plot elements (ticks, lines, etc.)
minor.tick(nx = 2, ny = 2, tick.ratio = 0.5)

# Plot linear regression line
lines(seq(0, 7000, length.out = 100), N_int_pr$fit, col = "#27462C", lwd = 2)

# Add shaded confidence interval area
polygon(c(seq(0, 7000, length.out = 100), rev(seq(0, 7000, length.out = 100))),
        c(N_int_pr$fit + 1.96 * N_int_pr$se.fit, rev(N_int_pr$fit - 1.96 * N_int_pr$se.fit)),
        col = rgb(0.7, 0.7, 0.7, 0.2), border = NA)

# Add the legend outside the plot area, below the title
legend("topright", 
       legend = c(paste0("n = ", nN_pr),
                  paste0("n = ", nN_prOutl)), 
       col = c("#27462C", # Pristine
               "#27462C"), 
       pch = c(0,4), 
       bty = "o", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F , 
       inset = c(0,0))

### Plot 7: Restored Ptot

# Set margin c(bottom, left, top, right) and adjust mgp c(axis labels, tickmark labels, tickmarks) 
par(mar = c(5, 5, 0.5, 1))

# Plot
plot(r_tot_P_ug_l ~ p_tot_P_ug_l, regres_rP,
     col = colors_restored[factor(period)], 
     pch = shapes_restored[factor(period)], cex = 1.2,
     ylim = c(0,1200), xlim = c(0,1500),
     ylab = expression("Runoff P"[tot]*", \u03BCg/l"), 
     xlab = expression("Porewater P"[tot]*", \u03BCg/l"))

# Add additional plot elements (ticks, lines, etc.)
minor.tick(nx = 2, ny = 2, tick.ratio = 0.5)

# Plot linear regression line
lines(seq(0, 1500, length.out = 100), P_int03$fit, col = "coral2", lwd = 2, lty = 2)

# Add shaded confidence interval area
polygon(c(seq(0, 1500, length.out = 100), rev(seq(0, 1500, length.out = 100))),
        c(P_int03$fit + 1.96 * P_int03$se.fit, rev(P_int03$fit - 1.96 * P_int03$se.fit)),
        col = rgb(0.7, 0.7, 0.7, 0.2), border = NA)

# Plot linear regression line
lines(seq(0, 1500, length.out = 100), P_int3$fit, col = "#7570B3", lwd = 2)

# Add shaded confidence interval area
polygon(c(seq(0, 1500, length.out = 100), rev(seq(0, 1500, length.out = 100))),
        c(P_int3$fit + 1.96 * P_int3$se.fit, rev(P_int3$fit - 1.96 * P_int3$se.fit)),
        col = rgb(0.7, 0.7, 0.7, 0.2), border = NA) 

# Add a legend inside the plot with count of datapoints n
legend("topright", 
       legend = c(paste0("n = ", nP_03),
                  paste0("n = ", nP_3),
                  paste0("n = ", nP_03Outl),
                  paste0("n = ", nP_3Outl)), 
       col = c("coral2", 
               "#7570B3",
               "coral2",
               "#7570B3"), 
       pch = c(2,1,4,4), 
       bty = "o", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F , 
       inset = c(0,0))


### Plot 8: Drained Ptot

# Set margin c(bottom, left, top, right) and adjust mgp c(axis labels, tickmark labels, tickmarks) 
par(mar = c(5, 3, 0.5, 1))

# Plot
plot(r_tot_P_ug_l ~ p_tot_P_ug_l, regres_d,
     col = "#222255", 
     pch = 6, cex = 1.2,
     ylim = c(0,120), xlim = c(0,850),
     ylab = "", 
     xlab = expression("Porewater P"[tot]*", \u03BCg/l"))

# Add additional plot elements (ticks, lines, etc.)
minor.tick(nx = 2, ny = 2, tick.ratio = 0.5)

# Segmented regression lines
plot(Pseg_dr, add = T, conf.level = 0.95, shade = T, col = "#222255")

# Add a legend inside the plot with count of datapoints n
legend("topright", 
       legend = paste0("n = ", nP_dr), 
       col = c("#222255"), 
       pch = c(6), 
       bty = "0", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F, 
       inset = c(0,0))


### Plot 9: Pristine Ptot

# Plot
plot(r_tot_P_ug_l ~ p_tot_P_ug_l, regres_pP,
     col = colors_pristine[factor(period)], 
     pch = shapes_pristine[factor(period)], cex = 1.2,
     ylim = c(0,120), xlim = c(0,850),
     ylab = "", 
     xlab = expression("Porewater P"[tot]*", \u03BCg/l"))

# Add additional plot elements (ticks, lines, etc.)
minor.tick(nx = 2, ny = 2, tick.ratio = 0.5)

# Plot linear regression line
lines(seq(0, 1500, length.out = 100), P_int_pr$fit, col = "#27462C", lwd = 2)

# Add shaded confidence interval area
polygon(c(seq(0, 1500, length.out = 100), rev(seq(0, 1500, length.out = 100))),
        c(P_int_pr$fit + 1.96 * P_int_pr$se.fit, rev(P_int_pr$fit - 1.96 * P_int_pr$se.fit)),
        col = rgb(0.7, 0.7, 0.7, 0.2), border = NA)

# Add the legend outside the plot area, below the title
legend("topright", 
       legend = c(paste0("n = ", nP_pr),
                  paste0("n = ", nP_prOutl)), 
       col = c("#27462C", # Pristine
               "#27462C"), 
       pch = c(0,4), 
       bty = "o", 
       pt.cex = 1.2, 
       cex = 1.2, 
       text.col = "black", 
       horiz = F , 
       inset = c(0,0))

# Turn off the plotting device
dev.off()
