library(ggplot2) # Plotting package
library(GGally)
library(scales)
library(patchwork) # To display 2 charts together
library(dplyr) # Data handling
library(lubridate) # Date and time handling
library(segmented) # Segmented regression analysis
library(Hmisc)

# Set working directory
setwd("C:/Users/lpakkila/OneDrive - Oulun yliopisto/Lassin väitöskirjatyö/Peatland water table and quality/Water_quality/Porewater_vs_runoff_quality/")

# Pull and treat data 
regres <- read.csv('porewater_and_runoff_quality_regression_V2.csv', 
                   header=TRUE, sep =";", quote="", dec=".", fill=TRUE, comment.char="", skipNul=FALSE)
regres$peatland <- as.numeric(regres$peatland)
regres$date <- dmy(regres$date, tz=NULL)
regres$p_pH <- as.numeric(regres$p_pH)
regres$fyear <- as.numeric(regres$fyear)
regres$r_NO23N_ug_l <- as.numeric(regres$r_NO23N_ug_l)
regres$r_SS_mg_l <- as.numeric(regres$r_SS_mg_l)
regres$r_Fe_ug_l <- as.numeric(regres$r_Fe_ug_l)
regres$p_tot_N_ug_l <- as.numeric(regres$p_tot_N_ug_l)

# Add period column to restored dataset
regres$period <- NA
regres$period[regres$fyear < 0] <- "<0"
regres$period[regres$fyear >=0 & regres$fyear <= 3] <- "0-3"
regres$period[regres$fyear >3] <- ">3"
regres$period[regres$res_pris == 2] <- "Pristine"
regres$period <- as.factor(regres$period)

# Custom theme for the plots
custom_theme <- theme_bw(base_size = 7) +
  theme(
    axis.title = element_text(size = 7),#, face = "bold"), # Adjust size and font properties for axis titles
    axis.text = element_text(size = 7),               # Adjust size and font properties for axis labels
    axis.text.y = element_text(angle = 90, hjust = 0.5),
    legend.position = "bottom",
    legend.text = element_text(size = 7))             # Adjust size and font properties for legend text

# List of sites to iterate through
sites <- c("S3", "F1", "F2", "F5", "F11/1")
  
# Loop through each site to create the plots and save variables
for (site in sites) {
  
  # Filter the data for each site
  site_data <- regres[regres$site == site, ]
  
  # Divide into drained, restored (0-3 years and >3 years), and pristine
  site_br <- site_data[site_data$period == "<0", ]
  site_03 <- site_data[site_data$res_pris == 1 & site_data$period == "0-3", ]
  site_3 <- site_data[site_data$res_pris == 1 & site_data$period == ">3", ]
  
  # Check if site data is sufficient to proceed with plotting
  if (nrow(site_br) > 0 & nrow(site_03) > 0 & nrow(site_3) > 0) {
    
    # Perform the linear regression and save to variables (drained, 0-3 years restored, >3 years restored)
    assign(paste0("fitP_br_", site), lm(r_tot_P_ug_l ~ p_tot_P_ug_l, data = site_br))
    assign(paste0("fitP_03_", site), lm(r_tot_P_ug_l ~ p_tot_P_ug_l, data = site_03))
    assign(paste0("fitP_3_", site), lm(r_tot_P_ug_l ~ p_tot_P_ug_l, data = site_3))
    
    # Calculate Spearman's rho
    assign(paste0("rhoP_br_", site), cor.test(site_br$r_tot_P_ug_l, site_br$p_tot_P_ug_l, method = "spearman")$estimate)
    assign(paste0("rhoP_03_", site), cor.test(site_03$r_tot_P_ug_l, site_03$p_tot_P_ug_l, method = "spearman")$estimate)
    assign(paste0("rhoP_3_", site), cor.test(site_3$r_tot_P_ug_l, site_3$p_tot_P_ug_l, method = "spearman")$estimate)
    
    # Calculate count of datapoints
    assign(paste0("nP_br_", site), min(sum(!is.na(site_br$r_tot_P_ug_l)), sum(!is.na(site_br$p_tot_P_ug_l))))
    assign(paste0("nP_03_", site), min(sum(!is.na(site_03$r_tot_P_ug_l)), sum(!is.na(site_03$p_tot_P_ug_l))))
    assign(paste0("nP_3_", site), min(sum(!is.na(site_3$r_tot_P_ug_l)), sum(!is.na(site_3$p_tot_P_ug_l))))
    
    # Adjust y-axis title based on the site
    if (site == "S3") {
      y_title <- expression("Runoff P"[tot]*", \u03BCg/l")
    } else {
      y_title = NULL
    }
    
    # Adjust axis limits based on the site
    if (site == "S3") {
      xlim_res <- c(0, 2000)
      ylim_res <- c(0, 1200)
      x_breaks <- seq(0, 10000, 500)
      y_breaks <- seq(0, 3000, 200)
      x_text1 <- 600
      x_text2 <- 1400
      y_text1 <- 900
      y_text2 <- 100
    } else {
      xlim_res <- c(0, 800)
      ylim_res <- c(0, 550)
      x_breaks <- seq(0, 10000, 100)
      y_breaks <- seq(0, 3000, 100)
      x_text1 <- 350
      x_text2 <- 350
      y_text1 <- 500
      y_text2 <- 150
    }
    
    # Create plots for restored
    assign(paste0("Ptot_res_", site),
           ggplot() +
             custom_theme +
             geom_smooth(data = site_03, aes(y = r_tot_P_ug_l, x = p_tot_P_ug_l), color = "coral2", method = "lm") +
             geom_point(data = site_03, aes(y = r_tot_P_ug_l, x = p_tot_P_ug_l), shape = 2, color = "coral2") +
             geom_smooth(data = site_3, aes(y = r_tot_P_ug_l, x = p_tot_P_ug_l), color = "#7570B3", method = "lm") +
             geom_point(data = site_3, aes(y = r_tot_P_ug_l, x = p_tot_P_ug_l), shape = 1, color = "#7570B3") +
             coord_cartesian(xlim = xlim_res, ylim = ylim_res) +
             scale_x_continuous(breaks = x_breaks) +
             scale_y_continuous(breaks = y_breaks) +
             labs(title = paste(site, "restored"),
                  x = NULL,
                  y = y_title) +
             annotate("text", x = x_text1, y = y_text1,
                      label = bquote(atop("0-3 years: y =" ~ .(round(coef(get(paste0("fitP_03_", site)))[2], 2)) ~ "x +" ~ .(round(coef(get(paste0("fitP_03_", site)))[1], 2)),
                                          R^2 == .(round(summary(get(paste0("fitP_03_", site)))$r.squared, 3)) *
                                            ", " * rho * " = " * .(round(get(paste0("rhoP_03_", site)), 3)) *
                                            ", n = " * .(get(paste0("nP_03_", site))))),
                      color = "coral2", size = 6/.pt) +
             annotate("text", x = x_text2, y = y_text2,
                      label = bquote(atop(">3 years: y =" ~ .(round(coef(get(paste0("fitP_3_", site)))[2], 2)) ~ "x +" ~ .(round(coef(get(paste0("fitP_3_", site)))[1], 2)),
                                          "R"^2 * " = " * .(round(summary(get(paste0("fitP_3_", site)))$r.squared, 3)) *
                                            ", " * rho * " = " * .(round(get(paste0("rhoP_3_", site)), 3)) *
                                            ", n = " * .(get(paste0("nP_3_", site))))),
                      color = "#7570B3", size = 6/.pt)
    )
    
    # Adjust x-axis title based on the site
    if (site == "F2" | site == "F11/1") {
      x_title <- expression("Porewater P"[tot]*", \u03BCg/l")
    } else {
      x_title = NULL
    }
    
    # Create plots for drained
    assign(paste0("Ptot_drain_", site),
           ggplot() +
             custom_theme +
             geom_smooth(data = site_br, aes(y = r_tot_P_ug_l, x = p_tot_P_ug_l), color = "#222255", method = "lm") +
             geom_point(data = site_br, aes(y = r_tot_P_ug_l, x = p_tot_P_ug_l), shape = 6, color = "#222255") +
             coord_cartesian(xlim = c(0,800), ylim = c(0,120))+
             scale_x_continuous(breaks = seq(0, 10000, 100)) +
             scale_y_continuous(breaks = seq(0, 3000, 20)) +
             labs(title = paste(site, "drained"),
                  x = x_title,
                  y = y_title) +
             annotate("text", x = 550, y = 110,
                      label = bquote(atop("y =" ~ .(round(coef(get(paste0("fitP_br_", site)))[2], 2)) ~ "x +" ~ .(round(coef(get(paste0("fitP_br_", site)))[1], 2)),
                                          R^2 == .(round(summary(get(paste0("fitP_br_", site)))$r.squared, 3)) *
                                            ", " * rho * " = " * .(round(get(paste0("rhoP_br_", site)), 3)) *
                                            ", n = " * .(get(paste0("nP_br_", site))))),
                      color = "#222255", size = 6/.pt)
    )
  }
}
  

Ptot_drain_S3
Ptot_drain_F1
Ptot_drain_F2
Ptot_drain_F5
`Ptot_drain_F11/1`
Ptot_res_S3
Ptot_res_F1
Ptot_res_F2
Ptot_res_F5
`Ptot_res_F11/1`

# List of sites to iterate through
sites <- c("SC3", "FC1", "FC5")

## Pristine
# Loop through each site to create the plots and save variables
for (site in sites) {
  
  # Filter the data for each site
  site_pr <- regres[regres$site == site, ]
  
  # Check if site data is sufficient to proceed with plotting
  if (nrow(site_pr) > 0) {
    
    # Perform the linear regression and save to variables 
    assign(paste0("fitP_pr_", site), lm(r_tot_P_ug_l ~ p_tot_P_ug_l, data = site_pr))
    
    # Calculate Spearman's rho
    assign(paste0("rhoP_pr_", site), cor.test(site_pr$r_tot_P_ug_l, site_pr$p_tot_P_ug_l, method = "spearman")$estimate)
    
    # Calculate count of datapoints
    assign(paste0("nP_pr_", site), min(sum(!is.na(site_pr$r_tot_P_ug_l)), sum(!is.na(site_pr$p_tot_P_ug_l))))
    
    # Adjust y-axis title based on the site
    if (site == "SC3") {
      y_title <- expression("Runoff P"[tot]*", \u03BCg/l")
    } else {
      y_title = NULL
    }
    
    # Create plots for pristine
    assign(paste0("Ptot_pris_", site),
           ggplot()+
             custom_theme +
             geom_smooth(data = site_pr, aes(y = r_tot_P_ug_l, x = p_tot_P_ug_l), color = "#27462C", method = "lm")+
             geom_point(data = site_pr, aes(y = r_tot_P_ug_l, x = p_tot_P_ug_l), shape = 0, color = "#27462C")+
             coord_cartesian(xlim = c(0,800), ylim = c(0,120))+
             scale_x_continuous(breaks = seq(0, 10000, 200))+
             scale_y_continuous(breaks = seq(0, 3000, 20))+
             labs(title = paste(site, "pristine"),
                  x = expression("Porewater P"[tot]*", \u03BCg/l"), 
                  y = y_title)+
             # Add regression equation, r-squared, count of datapoints, and Spearman's rho
             annotate("text", x = 550, y = 110,
                      label = bquote(atop("y =" ~ .(round(coef(get(paste0("fitP_pr_", site)))[2], 4)) ~ "x +" ~ .(round(coef(get(paste0("fitP_pr_", site)))[1], 2)),
                                          R^2 == .(round(summary(get(paste0("fitP_pr_", site)))$r.squared, 3)) *
                                            ", " * rho * " = " * .(round(get(paste0("rhoP_pr_", site)), 3)) *
                                            ", n = " * .(get(paste0("nP_pr_", site))))),
                      color = "#27462C", size = 6/.pt)
    )
  }
}

Ptot_pris_FC1
Ptot_pris_FC5
Ptot_pris_SC3


Ptot_plot <- (Ptot_res_S3 + Ptot_res_F1 + Ptot_res_F2 + Ptot_res_F5 + `Ptot_res_F11/1` + Ptot_drain_S3 + Ptot_drain_F1 + Ptot_drain_F2 + Ptot_drain_F5 + `Ptot_drain_F11/1` + Ptot_pris_SC3 + Ptot_pris_FC1 + plot_spacer() + Ptot_pris_FC5 + plot_spacer() + plot_layout(ncol = 5, widths = c(1,1,1,1,1))
)

# Start saving engine with the tiff() function (adjust parameters)
tiff(
  file = paste("Ptot_regression_sites_separately", ".tiff", sep = ""),
  width = 5800,   # Width in px
  height = 3600,  # Height in px
  units = "px",  # Specify units in px
  res = 500      # Set the desired DPI to 500
)
Ptot_plot
dev.off()

