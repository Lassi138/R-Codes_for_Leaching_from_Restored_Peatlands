library(ggplot2) # Plotting package
library(GGally)
library(scales)
library(patchwork) # To display 2 charts together
library(dplyr) # Data handling
library(lubridate) # Date and time handling
library(segmented) # Segmented regression analysis
library(Hmisc)

# Set working directory
setwd("C:/Users/lpakkila/OneDrive - Oulun yliopisto/Lassin väitöskirjatyö/Peatland water table and quality/Water_quality/Porewater_vs_runoff_quality/")

# Pull and treat data 
regres <- read.csv('porewater_and_runoff_quality_regression_V2.csv', 
                   header=TRUE, sep =";", quote="", dec=".", fill=TRUE, comment.char="", skipNul=FALSE)
regres$peatland <- as.numeric(regres$peatland)
regres$date <- dmy(regres$date, tz=NULL)
regres$p_pH <- as.numeric(regres$p_pH)
regres$fyear <- as.numeric(regres$fyear)
regres$r_NO23N_ug_l <- as.numeric(regres$r_NO23N_ug_l)
regres$r_SS_mg_l <- as.numeric(regres$r_SS_mg_l)
regres$r_Fe_ug_l <- as.numeric(regres$r_Fe_ug_l)
regres$p_tot_N_ug_l <- as.numeric(regres$p_tot_N_ug_l)

# Add period column to restored dataset
regres$period <- NA
regres$period[regres$fyear < 0] <- "<0"
regres$period[regres$fyear >=0 & regres$fyear <= 3] <- "0-3"
regres$period[regres$fyear >3] <- ">3"
regres$period[regres$res_pris == 2] <- "Pristine"
regres$period <- as.factor(regres$period)

# Custom theme for the plots
custom_theme <- theme_bw(base_size = 7) +
  theme(
    axis.title = element_text(size = 7),#, face = "bold"), # Adjust size and font properties for axis titles
    axis.text = element_text(size = 7),               # Adjust size and font properties for axis labels
    axis.text.y = element_text(angle = 90, hjust = 0.5),
    legend.position = "bottom",
    legend.text = element_text(size = 7))             # Adjust size and font properties for legend text

# List of sites to iterate through
sites <- c("S3", "F1", "F2", "F5", "F11/1")

# Loop through each site to create the plots and save variables
for (site in sites) {
  
  # Filter the data for each site
  site_data <- regres[regres$site == site, ]
  
  # Divide into drained, restored (0-3 years and >3 years), and pristine
  site_br <- site_data[site_data$period == "<0", ]
  site_03 <- site_data[site_data$res_pris == 1 & site_data$period == "0-3", ]
  site_3 <- site_data[site_data$res_pris == 1 & site_data$period == ">3", ]
  
  # List of sites to iterate through
  sites <- c("S3", "F1", "F2", "F5", "F11/1")
  
  # Loop through each site to create the plots and save variables
  for (site in sites) {
    
    # Filter the data for each site
    site_data <- regres[regres$site == site, ]
    
    # Divide into drained, restored (0-3 years and >3 years), and pristine
    site_br <- site_data[site_data$period == "<0", ]
    site_03 <- site_data[site_data$res_pris == 1 & site_data$period == "0-3", ]
    site_3 <- site_data[site_data$res_pris == 1 & site_data$period == ">3", ]
    
    # Adjust y-axis title based on the site
    if (site == "S3") {
      y_title <- "Runoff DOC mg/l"
    } else {
      y_title = NULL
    }
    
    # Check if site data is sufficient to proceed with plotting
    if (nrow(site_br) > 0 & nrow(site_03) > 0 & nrow(site_3) > 0) {
      
      # Perform the linear regression and save to variables (drained, 0-3 years restored, >3 years restored)
      assign(paste0("fitC_br_", site), lm(r_DOC_mg_l ~ p_DOC_mg_l, data = site_br))
      assign(paste0("fitC_03_", site), lm(r_DOC_mg_l ~ p_DOC_mg_l, data = site_03))
      assign(paste0("fitC_3_", site), lm(r_DOC_mg_l ~ p_DOC_mg_l, data = site_3))
      
      # Calculate Spearman's rho
      assign(paste0("rhoC_br_", site), cor.test(site_br$r_DOC_mg_l, site_br$p_DOC_mg_l, method = "spearman")$estimate)
      assign(paste0("rhoC_03_", site), cor.test(site_03$r_DOC_mg_l, site_03$p_DOC_mg_l, method = "spearman")$estimate)
      assign(paste0("rhoC_3_", site), cor.test(site_3$r_DOC_mg_l, site_3$p_DOC_mg_l, method = "spearman")$estimate)
      
      # Calculate count of datapoints
      assign(paste0("nC_br_", site), min(sum(!is.na(site_br$r_DOC_mg_l)), sum(!is.na(site_br$p_DOC_mg_l))))
      assign(paste0("nC_03_", site), min(sum(!is.na(site_03$r_DOC_mg_l)), sum(!is.na(site_03$p_DOC_mg_l))))
      assign(paste0("nC_3_", site), min(sum(!is.na(site_3$r_DOC_mg_l)), sum(!is.na(site_3$p_DOC_mg_l))))
      
      # Create plots for restored
      assign(paste0("DOC_res_", site),
             ggplot() +
               custom_theme +
               geom_smooth(data = site_03, aes(y = r_DOC_mg_l, x = p_DOC_mg_l), color = "coral2", method = "lm") +
               geom_point(data = site_03, aes(y = r_DOC_mg_l, x = p_DOC_mg_l), shape = 2, color = "coral2") +
               geom_smooth(data = site_3, aes(y = r_DOC_mg_l, x = p_DOC_mg_l), color = "#7570B3", method = "lm") +
               geom_point(data = site_3, aes(y = r_DOC_mg_l, x = p_DOC_mg_l), shape = 1, color = "#7570B3") +
               coord_cartesian(xlim = c(0, 180), ylim = c(0, 180)) +
               scale_x_continuous(breaks = seq(0, 180, 20)) +
               scale_y_continuous(breaks = seq(0, 180, 20)) +
               labs(title = paste(site, "restored"),
                    x = NULL,
                    y = y_title) +
               annotate("text", x = 65, y = 170,
                        label = bquote(atop("0-3 years: y =" ~ .(round(coef(get(paste0("fitC_03_", site)))[2], 2)) ~ "x +" ~ .(round(coef(get(paste0("fitC_03_", site)))[1], 2)),
                                            R^2 == .(round(summary(get(paste0("fitC_03_", site)))$r.squared, 3)) *
                                              ", " * rho * " = " * .(round(get(paste0("rhoC_03_", site)), 3)) *
                                              ", n = " * .(get(paste0("nC_03_", site))))),
                        color = "coral2", size = 7/.pt) +
               annotate("text", x = 115, y = 10,
                        label = bquote(atop(">3 years: y =" ~ .(round(coef(get(paste0("fitC_3_", site)))[2], 2)) ~ "x +" ~ .(round(coef(get(paste0("fitC_3_", site)))[1], 2)),
                                            "R"^2 * " = " * .(round(summary(get(paste0("fitC_3_", site)))$r.squared, 3)) *
                                              ", " * rho * " = " * .(round(get(paste0("rhoC_3_", site)), 3)) *
                                              ", n = " * .(get(paste0("nC_3_", site))))),
                        color = "#7570B3", size = 7/.pt)
      )
      
      # Adjust x-axis title based on the site
      if (site == "F2" | site == "F11/1") {
        x_title <- "Porewater DOC, mg/l"
      } else {
        x_title = NULL
      }
      
      # Create plots for drained
      assign(paste0("DOC_drain_", site),
             ggplot() +
               custom_theme +
               geom_smooth(data = site_br, aes(y = r_DOC_mg_l, x = p_DOC_mg_l), color = "#222255", method = "lm") +
               geom_point(data = site_br, aes(y = r_DOC_mg_l, x = p_DOC_mg_l), shape = 6, color = "#222255") +
               coord_cartesian(xlim = c(0,180), ylim = c(0,180)) +
               scale_x_continuous(breaks = seq(0, 180, 20)) +
               scale_y_continuous(breaks = seq(0, 180, 20)) +
               labs(title = paste(site, "drained"),
                    x = x_title,
                    y = y_title) +
               annotate("text", x = 65, y = 170,
                        label = bquote(atop("y =" ~ .(round(coef(get(paste0("fitC_br_", site)))[2], 2)) ~ "x +" ~ .(round(coef(get(paste0("fitC_br_", site)))[1], 2)),
                                            R^2 == .(round(summary(get(paste0("fitC_br_", site)))$r.squared, 3)) *
                                              ", " * rho * " = " * .(round(get(paste0("rhoC_br_", site)), 3)) *
                                              ", n = " * .(get(paste0("nC_br_", site))))),
                        color = "#222255", size = 7/.pt)
      )
    }
  }
}


DOC_drain_S3
DOC_drain_F1
DOC_drain_F2
DOC_drain_F5
`DOC_drain_F11/1`
DOC_res_S3
DOC_res_F1
DOC_res_F2
DOC_res_F5
`DOC_res_F11/1`

# List of sites to iterate through
sites <- c("SC3", "FC1", "FC5")

## Pristine
# Loop through each site to create the plots and save variables
for (site in sites) {
  
  # Filter the data for each site
  site_pr <- regres[regres$site == site, ]
  
  # Check if site data is sufficient to proceed with plotting
  if (nrow(site_pr) > 0) {
    
    # Perform the linear regression and save to variables 
    assign(paste0("fitC_pr_", site), lm(r_DOC_mg_l ~ p_DOC_mg_l, data = site_pr))
    
    # Calculate Spearman's rho
    assign(paste0("rhoC_pr_", site), cor.test(site_pr$r_DOC_mg_l, site_pr$p_DOC_mg_l, method = "spearman")$estimate)
    
    # Calculate count of datapoints
    assign(paste0("nC_pr_", site), min(sum(!is.na(site_pr$r_DOC_mg_l)), sum(!is.na(site_pr$p_DOC_mg_l))))
    
    # Adjust y-axis title based on the site
    if (site == "SC3") {
      y_title <- "Runoff DOC, mg/l"
    } else {
      y_title = NULL
    }
    
    # Create plots for pristine
    assign(paste0("DOC_pris_", site),
           ggplot()+
             custom_theme +
             geom_smooth(data = site_pr, aes(y = r_DOC_mg_l, x = p_DOC_mg_l), color = "#27462C", method = "lm")+
             geom_point(data = site_pr, aes(y = r_DOC_mg_l, x = p_DOC_mg_l), shape = 0, color = "#27462C")+
             coord_cartesian(xlim = c(0,180), ylim = c(0,180)) +
             scale_x_continuous(breaks = seq(0, 180, 20)) +
             scale_y_continuous(breaks = seq(0, 180, 20)) +
             labs(title = paste(site, "pristine"),
                  x = "Porewater DOC, mg/l", 
                  y = y_title)+
             # Add regression equation, r-squared, count of datapoints, and Spearman's rho
             annotate("text", x = 115, y = 170,
                      label = bquote(atop("y =" ~ .(round(coef(get(paste0("fitC_pr_", site)))[2], 4)) ~ "x +" ~ .(round(coef(get(paste0("fitC_pr_", site)))[1], 2)),
                                          R^2 == .(round(summary(get(paste0("fitC_pr_", site)))$r.squared, 3)) *
                                            ", " * rho * " = " * .(round(get(paste0("rhoC_pr_", site)), 3)) *
                                            ", n = " * .(get(paste0("nC_pr_", site))))),
                      color = "#27462C", size = 7/.pt)
    )
  }
}

DOC_pris_FC1
DOC_pris_FC5
DOC_pris_SC3


DOC_plot <- (DOC_res_S3 + DOC_res_F1 + DOC_res_F2 + DOC_res_F5 + `DOC_res_F11/1` + DOC_drain_S3 + DOC_drain_F1 + DOC_drain_F2 + DOC_drain_F5 + `DOC_drain_F11/1` + DOC_pris_SC3 + DOC_pris_FC1 + plot_spacer() + DOC_pris_FC5 + plot_spacer() + plot_layout(ncol = 5, widths = c(1,1,1,1,1))
)

# Start saving engine with the tiff() function (adjust parameters)
tiff(
  file = paste("DOC_regression_sites_separately", ".tiff", sep = ""),
  width = 5800,   # Width in px
  height = 3600,  # Height in px
  units = "px",  # Specify units in px
  res = 500      # Set the desired DPI to 500
)
DOC_plot
dev.off()

