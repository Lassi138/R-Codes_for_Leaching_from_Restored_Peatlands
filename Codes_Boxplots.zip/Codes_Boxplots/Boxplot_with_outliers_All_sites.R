library(dplyr) # Data handling
library(ggplot2) # Plotting package
library(tidyquant)
library(ggdist)
library(ggthemes)
library(gghalves)
library(GGally)
library(scales)
library(patchwork) # To display 2 charts together
library(lubridate) # Date and time handling
library(tidyverse)

# Set working directory
setwd("C:/Users/lpakkila/OneDrive - Oulun yliopisto/Lassin väitöskirjatyö/Peatland water table and quality/Water_quality/Porewater_vs_runoff_quality/")

# Pull and treat water wq_df data
wq_df <- read.csv('water_quality_all_V2.csv', 
                  header=TRUE, sep =";", quote="", dec=".", fill=TRUE, comment.char="", skipNul=FALSE)
wq_df$peatland <- as.numeric(wq_df$peatland)
wq_df$res_pris <- as.numeric(wq_df$res_pris)
wq_df$date <- dmy(wq_df$date, tz=NULL)
wq_df$fyear <- as.numeric(wq_df$fyear)
wq_df$r_gran_mmol_l <- as.numeric(wq_df$r_gran_mmol_l)
wq_df$r_NO23N_ug_l <- as.numeric(wq_df$r_NO23N_ug_l)
wq_df$r_tot_N_ug_l <- as.numeric(wq_df$r_tot_N_ug_l)
wq_df$r_SS_mg_l <- as.numeric(wq_df$r_SS_mg_l)
wq_df$p_tot_N_ug_l <- as.numeric(wq_df$p_tot_N_ug_l)

# Add period column
wq_df$period <- NA
wq_df$period[wq_df$fyear < 0] <- "<0"
wq_df$period[wq_df$fyear >= 0 & wq_df$fyear <= 1] <- "0-1"
wq_df$period[wq_df$fyear > 1 & wq_df$fyear <= 5] <- "1-5"
wq_df$period[wq_df$fyear > 5] <- ">5"
wq_df$period <- ifelse(is.na(wq_df$fyear), "Pristine", wq_df$period)
wq_df$period <- as.factor(wq_df$period)
# Add month column
wq_df$month <- NA
wq_df$month <- as.factor(format(wq_df$date,'%m'))
# Add a calendar year column
wq_df$cal_year <- NA
wq_df$cal_year <- as.factor(format(wq_df$date, '%Y'))

# Custom theme for the plots
custom_theme <- theme_bw(base_size = 10) +
  theme(
    axis.title = element_text(size = 10),#, face = "bold"), # Adjust size and font properties for axis titles
    axis.text = element_text(size = 10),               # Adjust size and font properties for axis labels
    legend.position = "top",
    legend.text = element_text(size = 10)              # Adjust size and font properties for legend text
  )
# X-axis title
x_title <- c(NULL)

# Periodic box plots with outliers included

# Plot pH data (OUTLIERS INCLUDED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_pH, p_pH), names_to = "pH_type", values_to = "pH_value")

# Calculate the count (N) and mean for each group, excluding NA values
summary_data <- plot_data %>%
  group_by(period, pH_type) %>%
  summarise(N = sum(!is.na(pH_value)), Mean = mean(pH_value, na.rm = TRUE))

# Plot using geom_boxplot
pHo <- ggplot(plot_data, aes(x = factor(period), y = pH_value, colour = pH_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = 1, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Porewater", "Runoff")) +
  theme(legend.position = "bottom") +
  coord_cartesian(ylim = c(2.25, 7.5)) +
  scale_y_continuous(breaks = seq(0, 7, 1)) + 
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = "pH") +
  
  # Add N labels for each pH_type with subscripts
  geom_text(data = subset(summary_data, pH_type == "p_pH"),
            aes(x = factor(period), y = 7.2,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, pH_type == "r_pH"),
            aes(x = factor(period), y = 7.2,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)


# Plot EC data (OUTLIERS INCLUDED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_EC_mS_m, p_EC_mS_m), names_to = "EC_type", values_to = "EC_value")

# Calculate the count (N) and mean for each group, excluding NA values
summary_data <- plot_data %>%
  group_by(period, EC_type) %>%
  summarise(N = sum(!is.na(EC_value)), Mean = mean(EC_value, na.rm = TRUE))

# Plot using geom_boxplot
ECo <- ggplot(plot_data, aes(x = factor(period), y = EC_value, colour = EC_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = 1, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Porewater", "Runoff")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0,14.5)) +
  scale_y_continuous(breaks = seq(0, 14, 2)) + 
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = "EC, mS/m") +
  
  # Add N labels for each EC_type with subscripts
  geom_text(data = subset(summary_data, EC_type == "p_EC_mS_m"),
            aes(x = factor(period), y = 13.6,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, EC_type == "r_EC_mS_m"),
            aes(x = factor(period), y = 13.6,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)




# Plot ABS data (OUTLIERS INCLUDED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_ABS_254_nm, p_ABS_254_nm), names_to = "ABS_type", values_to = "ABS_value")

# Calculate the count (N) and mean for each group, excluding NA values
summary_data <- plot_data %>%
  group_by(period, ABS_type) %>%
  summarise(N = sum(!is.na(ABS_value)), Mean = mean(ABS_value, na.rm = TRUE))

# Plot using geom_boxplot
ABSo <- ggplot(plot_data, aes(x = factor(period), y = ABS_value, colour = ABS_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = 1, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Porewater", "Runoff")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0,16)) +
  scale_y_continuous(breaks = seq(0, 16, 1)) + 
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = "UV-254") +
  
  # Add N labels for each ABS_type with subscripts
  geom_text(data = subset(summary_data, ABS_type == "p_ABS_254_nm"),
            aes(x = factor(period), y = 15.2,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, ABS_type == "r_ABS_254_nm"),
            aes(x = factor(period), y = 15.2,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)



# Plot DOC data (OUTLIERS INCLUDED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_DOC_mg_l, p_DOC_mg_l), names_to = "DOC_type", values_to = "DOC_value")

# Calculate the count (N) and mean for each group, excluding NA values
summary_data <- plot_data %>%
  group_by(period, DOC_type) %>%
  summarise(N = sum(!is.na(DOC_value)), Mean = mean(DOC_value, na.rm = TRUE))

# Plot using geom_boxplot
DOCo <- ggplot(plot_data, aes(x = factor(period), y = DOC_value, colour = DOC_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = 1, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Porewater", "Runoff")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0,204)) +
  scale_y_continuous(breaks = seq(0, 200, 20)) +
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = "DOC, mg/l") +
  
  # Add N labels for each DOC_type with subscripts
  geom_text(data = subset(summary_data, DOC_type == "p_DOC_mg_l"),
            aes(x = factor(period), y = 192,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, DOC_type == "r_DOC_mg_l"),
            aes(x = factor(period), y = 192,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)



# Plot SUVA data (OUTLIERS INCLUDED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_SUVA, p_SUVA), names_to = "SUVA_type", values_to = "SUVA_value")

# Calculate the count (N) and mean for each group, excluding NA values
summary_data <- plot_data %>%
  group_by(period, SUVA_type) %>%
  summarise(N = sum(!is.na(SUVA_value)), Mean = mean(SUVA_value, na.rm = TRUE))

# Plot using geom_boxplot
SUVAo <- ggplot(plot_data, aes(x = factor(period), y = SUVA_value, colour = SUVA_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = 1, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Porewater", "Runoff")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0,15.2)) +
  scale_y_continuous(breaks = seq(0, 15, 2)) +
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = "SUVA") +
  
  # Add N labels for each SUVA_type with subscripts
  geom_text(data = subset(summary_data, SUVA_type == "p_SUVA"),
            aes(x = factor(period), y = 14.3,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, SUVA_type == "r_SUVA"),
            aes(x = factor(period), y = 14.3,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)



# Plot Ptot data (OUTLIERS INCLUDED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_tot_P_ug_l, p_tot_P_ug_l), names_to = "P_type", values_to = "P_value")

# Calculate the count (N) and mean for each group, excluding NA values
summary_data <- plot_data %>%
  group_by(period, P_type) %>%
  summarise(N = sum(!is.na(P_value)), Mean = mean(P_value, na.rm = TRUE))

# Plot using geom_boxplot
Po <- ggplot(plot_data, aes(x = factor(period), y = P_value, colour = P_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = 1, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Porewater", "Runoff")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0,1710)) +
  scale_y_continuous(breaks = seq(0, 1650, 200))+
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = expression("P"[tot]*", \u03BCg/l"),) +
  
  # Add N labels for each P_type with subscripts
  geom_text(data = subset(summary_data, P_type == "p_tot_P_ug_l"),
            aes(x = factor(period), y = 1610,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, P_type == "r_tot_P_ug_l"),
            aes(x = factor(period), y = 1610,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)



# Plot Ntot data (OUTLIERS INCLUDED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_tot_N_ug_l, p_tot_N_ug_l), names_to = "N_type", values_to = "N_value")

# Calculate the count (N) and mean for each group, excluding NA values
summary_data <- plot_data %>%
  group_by(period, N_type) %>%
  summarise(N = sum(!is.na(N_value)), Mean = mean(N_value, na.rm = TRUE))

# Plot using geom_boxplot
No <- ggplot(plot_data, aes(x = factor(period), y = N_value, colour = N_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = 1, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Porewater", "Runoff")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0,7430)) +
  scale_y_continuous(breaks = seq(0,7300, 1000))+
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = expression("N "[tot]*", \u03BCg/l"),) +
  
  # Add N labels for each N_type with subscripts
  geom_text(data = subset(summary_data, N_type == "p_tot_N_ug_l"),
            aes(x = factor(period), y = 7000,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, N_type == "r_tot_N_ug_l"),
            aes(x = factor(period), y = 7000,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)
# Combine plots
Boxplots <- (DOCo | No | Po ) /
  (SUVAo | pHo | ECo)
Boxplots

# Save the plot using ggsave
ggsave("Boxplots_w_outl.tiff", 
       plot = Boxplots, 
       device = "tiff", 
       width = 3740, height = 2493, dpi = 500, units = "px", bg = "white")