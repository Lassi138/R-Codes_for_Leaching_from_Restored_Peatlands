library(dplyr) # Data handling
library(ggplot2) # Plotting package
library(tidyquant)
library(ggdist)
library(ggthemes)
library(gghalves)
library(GGally)
library(scales)
library(patchwork) # To display 2 charts together
library(lubridate) # Date and time handling
library(tidyverse)

# Set working directory
setwd("C:/Users/lpakkila/OneDrive - Oulun yliopisto/Lassin väitöskirjatyö/Peatland water table and quality/Water_quality/Porewater_vs_runoff_quality/")

# Pull and treat water wq_df data
wq_df <- read.csv('water_quality_all_V2.csv', 
                  header=TRUE, sep =";", quote="", dec=".", fill=TRUE, comment.char="", skipNul=FALSE)
wq_df$peatland <- as.numeric(wq_df$peatland)
wq_df$res_pris <- as.numeric(wq_df$res_pris)
wq_df$date <- dmy(wq_df$date, tz=NULL)
wq_df$fyear <- as.numeric(wq_df$fyear)
wq_df$r_gran_mmol_l <- as.numeric(wq_df$r_gran_mmol_l)
wq_df$r_NO23N_ug_l <- as.numeric(wq_df$r_NO23N_ug_l)
wq_df$r_tot_N_ug_l <- as.numeric(wq_df$r_tot_N_ug_l)
wq_df$r_SS_mg_l <- as.numeric(wq_df$r_SS_mg_l)
wq_df$p_tot_N_ug_l <- as.numeric(wq_df$p_tot_N_ug_l)

# Add period column
wq_df$period <- NA
wq_df$period[wq_df$fyear < 0] <- "<0"
wq_df$period[wq_df$fyear >= 0 & wq_df$fyear <= 1] <- "0-1"
wq_df$period[wq_df$fyear > 1 & wq_df$fyear <= 5] <- "1-5"
wq_df$period[wq_df$fyear > 5] <- ">5"
wq_df$period <- ifelse(is.na(wq_df$fyear), "Pristine", wq_df$period)
wq_df$period <- as.factor(wq_df$period)
# Add month column
wq_df$month <- NA
wq_df$month <- as.factor(format(wq_df$date,'%m'))
# Add a calendar year column
wq_df$cal_year <- NA
wq_df$cal_year <- as.factor(format(wq_df$date, '%Y'))

# Custom theme for the plots
custom_theme <- theme_bw(base_size = 10) +
  theme(
    axis.title = element_text(size = 10),#, face = "bold"), # Adjust size and font properties for axis titles
    axis.text = element_text(size = 10),               # Adjust size and font properties for axis labels
    legend.position = "top",
    legend.text = element_text(size = 10)              # Adjust size and font properties for legend text
  )
# X-axis title
x_title <- c(NULL)
# Periodical box plots outliers removed

# Plot pH data (OUTLIERS REMOVED) 
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_pH, p_pH), names_to = "pH_type", values_to = "pH_value")

# Calculate the count (N) and mean for each group within 1.5 * IQR, excluding NA values
summary_data <- plot_data %>%
  group_by(period, pH_type) %>%
  summarise(
    N = sum(!is.na(pH_value) 
            & pH_value >= quantile(pH_value, 0.25, na.rm = TRUE) 
            - 1.5 * IQR(pH_value, na.rm = TRUE) 
            & pH_value <= quantile(pH_value, 0.75, na.rm = TRUE) 
            + 1.5 * IQR(pH_value, na.rm = TRUE)),
    Mean = mean(pH_value, na.rm = TRUE))

# Plot using geom_boxplot
pH <- ggplot(plot_data, aes(x = factor(period), y = pH_value, colour = pH_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = NA, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Porewater", "Runoff")) +
  theme(legend.position = "bottom") +
  coord_cartesian(ylim = c(3.5, 6.85)) +
  scale_y_continuous(breaks = seq(0, 6.5, 0.5)) + 
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = "pH") +
  
  # Add N labels for each pH_type with subscripts
  geom_text(data = subset(summary_data, pH_type == "p_pH"),
            aes(x = factor(period), y = 6.63,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, pH_type == "r_pH"),
            aes(x = factor(period), y = 6.63,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)
pH

# Plot EC data (OUTLIERS REMOVED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_EC_mS_m, p_EC_mS_m), names_to = "EC_type", values_to = "EC_value")

# Calculate the count (N) and mean for each group within 1.5 * IQR, excluding NA values
summary_data <- plot_data %>%
  group_by(period, EC_type) %>%
  summarise(
    N = sum(!is.na(EC_value) 
            & EC_value >= quantile(EC_value, 0.25, na.rm = TRUE) 
            - 1.5 * IQR(EC_value, na.rm = TRUE) 
            & EC_value <= quantile(EC_value, 0.75, na.rm = TRUE) 
            + 1.5 * IQR(EC_value, na.rm = TRUE)),
    Mean = mean(EC_value, na.rm = TRUE))

# Plot using geom_boxplot
EC <- ggplot(plot_data, aes(x = factor(period), y = EC_value, colour = EC_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = NA, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Pore water", "Runoff water")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0.4,13.3)) +
  scale_y_continuous(breaks = seq(0, 13.3, 2)) + 
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = "EC, mS/m") +
  
  # Add N labels for each EC_type with subscripts
  geom_text(data = subset(summary_data, EC_type == "p_EC_mS_m"),
            aes(x = factor(period), y = 12.5,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, EC_type == "r_EC_mS_m"),
            aes(x = factor(period), y = 12.5,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)
EC

# Plot UV 254 data (OUTLIERS REMOVED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_ABS_254_nm, p_ABS_254_nm), names_to = "ABS_type", values_to = "ABS_value")

# Calculate the count (N) and mean for each group within 1.5 * IQR, excluding NA values
summary_data <- plot_data %>%
  group_by(period, ABS_type) %>%
  summarise(
    N = sum(!is.na(ABS_value) 
            & ABS_value >= quantile(ABS_value, 0.25, na.rm = TRUE) 
            - 1.5 * IQR(ABS_value, na.rm = TRUE) 
            & ABS_value <= quantile(ABS_value, 0.75, na.rm = TRUE) 
            + 1.5 * IQR(ABS_value, na.rm = TRUE)),
    Mean = mean(ABS_value, na.rm = TRUE))

# Plot using geom_boxplot
ABS <- ggplot(plot_data, aes(x = factor(period), y = ABS_value, colour = ABS_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = NA, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Pore water", "Runoff water")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0,4.5)) +
  scale_y_continuous(breaks = seq(0, 15, 0.5)) + 
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = "UV 254") +
  
  # Add N labels for each EC_type with subscripts
  geom_text(data = subset(summary_data, ABS_type == "p_ABS_254_nm"),
            aes(x = factor(period), y = 4.25,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, ABS_type == "r_ABS_254_nm"),
            aes(x = factor(period), y = 4.25,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)
ABS


# Plot DOC data (OUTLIERS REMOVED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_DOC_mg_l, p_DOC_mg_l), names_to = "DOC_type", values_to = "DOC_value")

# Calculate the count (N) and mean for each group within 1.5 * IQR, excluding NA values
summary_data <- plot_data %>%
  group_by(period, DOC_type) %>%
  summarise(
    N = sum(!is.na(DOC_value) 
            & DOC_value >= quantile(DOC_value, 0.25, na.rm = TRUE) 
            - 1.5 * IQR(DOC_value, na.rm = TRUE) 
            & DOC_value <= quantile(DOC_value, 0.75, na.rm = TRUE) 
            + 1.5 * IQR(DOC_value, na.rm = TRUE)),
    Mean = mean(DOC_value, na.rm = TRUE))

# Plot using geom_boxplot
DOC <- ggplot(plot_data, aes(x = factor(period), y = DOC_value, colour = DOC_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = NA, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Pore water", "Runoff water")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0,135)) +
  scale_y_continuous(breaks = seq(0, 130, 20)) +
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = "DOC, mg/l") +
  
  # Add N labels for each EC_type with subscripts
  geom_text(data = subset(summary_data, DOC_type == "p_DOC_mg_l"),
            aes(x = factor(period), y = 126,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, DOC_type == "r_DOC_mg_l"),
            aes(x = factor(period), y = 126,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)
DOC


# Plot SUVA data (OUTLIERS REMOVED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_SUVA, p_SUVA), names_to = "SUVA_type", values_to = "SUVA_value")

# Calculate the count (N) and mean for each group within 1.5 * IQR, excluding NA values
summary_data <- plot_data %>%
  group_by(period, SUVA_type) %>%
  summarise(
    N = sum(!is.na(SUVA_value) 
            & SUVA_value >= quantile(SUVA_value, 0.25, na.rm = TRUE) 
            - 1.5 * IQR(SUVA_value, na.rm = TRUE) 
            & SUVA_value <= quantile(SUVA_value, 0.75, na.rm = TRUE) 
            + 1.5 * IQR(SUVA_value, na.rm = TRUE)),
    Mean = mean(SUVA_value, na.rm = TRUE))

# Plot using geom_boxplot
SUVA <- ggplot(plot_data, aes(x = factor(period), y = SUVA_value, colour = SUVA_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = NA, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Pore water", "Runoff water")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(1,6.85)) +
  scale_y_continuous(breaks = seq(1, 6.7, 1)) +
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = "SUVA") +
  
  # Add N labels for each EC_type with subscripts
  geom_text(data = subset(summary_data, SUVA_type == "p_SUVA"),
            aes(x = factor(period), y = 6.45,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, SUVA_type == "r_SUVA"),
            aes(x = factor(period), y = 6.45,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)
SUVA


# Plot Ptot data (OUTLIERS REMOVED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_tot_P_ug_l, p_tot_P_ug_l), names_to = "P_type", values_to = "P_value")

# Calculate the count (N) and mean for each group within 1.5 * IQR, excluding NA values
summary_data <- plot_data %>%
  group_by(period, P_type) %>%
  summarise(
    N = sum(!is.na(P_value) 
            & P_value >= quantile(P_value, 0.25, na.rm = TRUE) 
            - 1.5 * IQR(P_value, na.rm = TRUE) 
            & P_value <= quantile(P_value, 0.75, na.rm = TRUE) 
            + 1.5 * IQR(P_value, na.rm = TRUE)),
    Mean = mean(P_value, na.rm = TRUE))

# Plot using geom_boxplot
P <- ggplot(plot_data, aes(x = factor(period), y = P_value, colour = P_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = NA, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Pore water", "Runoff water")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0,240)) +
  scale_y_continuous(breaks = seq(0,200,50)) +
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = x_title,
       y = expression("P"[tot]*", \u03BCg/l"),) +
  
  # Add N labels for each EC_type with subscripts
  geom_text(data = subset(summary_data, P_type == "p_tot_P_ug_l"),
            aes(x = factor(period), y = 223,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, P_type == "r_tot_P_ug_l"),
            aes(x = factor(period), y = 223,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)
P



# Plot Ntot data (OUTLIERS REMOVED)
# Pivot the data for plotting
plot_data <- wq_df %>%
  pivot_longer(cols = c(r_tot_N_ug_l, p_tot_N_ug_l), names_to = "N_type", values_to = "N_value")

# Calculate the count (N) and mean for each group within 1.5 * IQR, excluding NA values
summary_data <- plot_data %>%
  group_by(period, N_type) %>%
  summarise(
    N = sum(!is.na(N_value) 
            & N_value >= quantile(N_value, 0.25, na.rm = TRUE) 
            - 1.5 * IQR(N_value, na.rm = TRUE) 
            & N_value <= quantile(N_value, 0.75, na.rm = TRUE) 
            + 1.5 * IQR(N_value, na.rm = TRUE)),
    Mean = mean(N_value, na.rm = TRUE))

# Plot using geom_boxplot
N <- ggplot(plot_data, aes(x = factor(period), y = N_value, colour = N_type)) +
  custom_theme +
  stat_boxplot(lwd = 0.25, geom = 'errorbar', width = 0.5, position = position_dodge(0.6)) +
  geom_boxplot(lwd = 0.25, width = 0.5, outlier.shape = NA, position = position_dodge(0.6)) +
  scale_colour_discrete(name = NULL, labels = c("Porewater", "Runoff")) +
  theme(legend.position = "none") +
  coord_cartesian(ylim = c(0,3000)) +
  scale_y_continuous(breaks = seq(0,2500,500)) +
  scale_x_discrete(limits = c("Pristine", "<0", "0-1", "1-5", ">5")) +
  labs(x = NULL,
       y = expression("N"[tot]*", \u03BCg/l"),) +
  
  # Add N labels for each EC_type with subscripts
  geom_text(data = subset(summary_data, N_type == "p_tot_N_ug_l"),
            aes(x = factor(period), y = 2800,
                label = paste("n[p] == ", N)),
            hjust = 0.5, vjust = -0.6, size = 2.1, color = "black", parse = TRUE) +
  geom_text(data = subset(summary_data, N_type == "r_tot_N_ug_l"),
            aes(x = factor(period), y = 2850,
                label = paste("n[r] == ", N)),
            hjust = 0.5, vjust = 0.6, size = 2.1, color = "black", parse = TRUE)
N

# Combine plots
Boxplots <- (DOC | N | P ) /
           (SUVA | pH | EC)
Boxplots

# Save the plot using ggsave
ggsave("Boxplots_wo_outl.tiff", 
       plot = Boxplots, 
       device = "tiff", 
       width = 3740, height = 2493, dpi = 500, units = "px", bg = "white")