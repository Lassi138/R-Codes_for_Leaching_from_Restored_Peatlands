library(lubridate)
library(dplyr)
library(ggplot2)

# Set working directory
setwd("C:/Users/lpakkila/OneDrive - Oulun yliopisto/Lassin väitöskirjatyö/Peatland water table and quality/Runoff_and_load/")
# Set the locale to English
Sys.setlocale("LC_TIME", "C")

# Read and check runoff and load data
load_df <- read.csv('Daily_data/CSV_Daily_runoff_and_load/daily_load_PATO-17.csv',
                    sep = ";", header = TRUE)
load_df$Date <- dmy(load_df$Date, tz = NULL)
load_df$Fe_ug_l <- as.numeric(load_df$Fe_ug_l)

# Add a calendar year column
load_df$cal_year <- NA
load_df$cal_year <- as.factor(format(load_df$Date, '%Y'))

# Custom theme for the plots
custom_theme <- theme_bw(base_size = 10) +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5),
    axis.title = element_text(size = 10),    # Adjust size and font properties for axis titles
    axis.text = element_text(size = 10),               # Adjust size and font properties for axis labels
    legend.position = "none",
    legend.text = element_text(size = 10),              # Adjust size and font properties for legend text
    panel.grid.major.x = element_line(color = "gray")
  )  

# Create a sequence of breaks for every 6 months starting from January
date_breaks <- seq(as.Date("2008-01-01"), as.Date("2022-12-31"), by = "6 months")

# Create PO4-P load plot with time on X-axis
PO4P_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = PO4P_kg_ha, group = cal_year), color = "cyan4", 
            linewidth = 0.5) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("PO"[4]*"-P load (kg ha"^-1*")")) +
  coord_cartesian(ylim = c(0, 0.0025)) +
  scale_y_continuous(breaks = seq(0, 5, 0.0005)) +
  scale_x_date(breaks = date_breaks,
               labels = strftime(date_breaks, format = "%b %Y"))
PO4P_load
# Save the plot using ggsave
ggsave("SC3_PO4-P_daily_load_timeline.tiff", 
       plot = PO4P_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")

# Create Ptot load plot with time on X-axis
Ptot_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = Ptot_kg_ha, group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("P"[tot]*" load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 0.0032)) +
  scale_y_continuous(breaks = seq(0, 20, 0.001)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
Ptot_load
# Save the plot using ggsave
ggsave("SC3_Ptot_daily_load_timeline.tiff", 
       plot = Ptot_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")

# Create NH4+N load plot with time on X-axis
NH4N_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = NH4N_kg_ha, group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("NH"[4]*"+N load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 0.0005)) +
  scale_y_continuous(breaks = seq(0, 20, 0.0001)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
NH4N_load
# Save the plot using ggsave
ggsave("SC3_NH4+N_daily_load_timeline.tiff", 
       plot = NH4N_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")

# Create NO23-N load plot with time on X-axis
NO23N_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = NO23N_kg_ha,  group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("NO"[2/3]*"-N load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 0.0007)) +
  scale_y_continuous(breaks = seq(0, 20, 0.0002)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
NO23N_load
# Save the plot using ggsave
ggsave("SC3_NO23-N_daily_load_timeline.tiff", 
       plot = NO23N_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")


# Create Ntot load plot with time on X-axis
Ntot_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = Ntot_kg_ha,  group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("N"[tot]*" load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 0.035)) +
  scale_y_continuous(breaks = seq(0, 20, 0.01)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
Ntot_load
# Save the plot using ggsave
ggsave("SC3_Ntot_daily_load_timeline.tiff", 
       plot = Ntot_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")

# Create SS load plot with time on X-axis
SS_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = SS_kg_ha,  group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("SS load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 0.035)) +
  scale_y_continuous(breaks = seq(0, 20, 0.01)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
SS_load
# Save the plot using ggsave
ggsave("SC3_SS_daily_load_timeline.tiff", 
       plot = SS_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")

# Create DOC load plot with time on X-axis
DOC_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = DOC_kg_ha,  group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("DOC load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 2)) +
  scale_y_continuous(breaks = seq(0, 200, 0.5)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
DOC_load
# Save the plot using ggsave
ggsave("SC3_DOC_daily_load_timeline.tiff", 
       plot = DOC_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")

# Create Fe load plot with time on X-axis
Fe_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = Fe_kg_ha,  group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("Fe load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 0.05)) +
  scale_y_continuous(breaks = seq(0, 200, 0.01)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
Fe_load
# Save the plot using ggsave
ggsave("SC3_Fe_daily_load_timeline.tiff", 
       plot = Fe_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")

# Create Na load plot with time on X-axis
Na_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = Na_kg_ha,  group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("Na load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 0.12)) +
  scale_y_continuous(breaks = seq(0, 200, 0.02)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
Na_load
# Save the plot using ggsave
ggsave("SC3_Na_daily_load_timeline.tiff", 
       plot = Na_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")

# Create K load plot with time on X-axis
K_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = K_kg_ha,  group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("K load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 0.02)) +
  scale_y_continuous(breaks = seq(0, 200, 0.005)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
K_load
# Save the plot using ggsave
ggsave("SC3_K_daily_load_timeline.tiff", 
       plot = K_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")


# Create NH4+N load plot with time on X-axis
Ca_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = Ca_kg_ha,  group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("Ca load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 0.08)) +
  scale_y_continuous(breaks = seq(0, 200, 0.02)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
Ca_load
# Save the plot using ggsave
ggsave("SC3_Ca_daily_load_timeline.tiff", 
       plot = Ca_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")

# Create Mg load plot with time on X-axis
Mg_load <- ggplot() +
  geom_line(data = load_df, aes(x = Date, y = Mg_kg_ha,  group = cal_year), color = "cyan4", 
            linewidth = 0.5, key_glyph = draw_key_smooth) +
  custom_theme +
  labs(title = "SC3" , 
       x = NULL,
       y = expression("Mg load (kg ha"^-1*")"),) +
  coord_cartesian(ylim = c(0, 0.035)) +
  scale_y_continuous(breaks = seq(0, 200, 0.01)) +
  scale_x_date(breaks = date_breaks,                
               labels = strftime(date_breaks, format = "%b %Y"))
Mg_load
# Save the plot using ggsave
ggsave("SC3_Mg_daily_load_timeline.tiff", 
       plot = Mg_load, 
       device = "tiff", 
       width = 3740, height = 1450, dpi = 500, units = "px", bg = "white")
